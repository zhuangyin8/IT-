function drag() {
    var mumu = document.getElementById("mumu"),
        message=document.getElementById('message'),
        spig = document.getElementById("spig"),
        x = 0,
        y = 0,
        flag = 0;
    mumu.addEventListener("mousedown", function(event) {
        message.innerText = "干嘛按人家啊，哼！";
        x = event.clientX - spig.offsetLeft;
        y = event.clientY - spig.offsetTop;
        flag = 1;
    });
    mumu.addEventListener("mousemove", function(event) {
        message.innerText = "想带人家去哪里啊？";
        if (flag == 1) {
            var out1 = event.clientX - x;
            var out2 = event.clientY - y;
            if (out1 > window.innerWidth - spig.offsetWidth) {
                out1 = window.innerWidth - spig.offsetWidth;
            }
            if (out1 < 0) {
                out1 = 0;
            }
            if (out2 > window.innerHeight - spig.offsetHeight) {
                out2 = window.innerHeight - spig.offsetHeight;
            }
            if (out2 < 0) {
                out2 = 0;
            }
            spig.style.left = out1 + "px";
            spig.style.top = out2 + "px";
        }
    });
    mumu.addEventListener("mouseup", function(event) {
        flag = 0;
    });
    mumu.addEventListener('mouseover', function() {
        message.innerText = "讨厌，又来撩拨人家！";
    });
    mumu.addEventListener("mouseout", function(event) {
        message.innerText = "来啊，撩我啊~~~";
    });
}
drag();
