'use strict';
angular.module('skillApp')
    .factory('commonUtil', function ($rootScope, $state, $filter) {
        return {
            //产生min-max之间的随机数
            getRandom: function (min, max) {
                return Math.floor(Math.random() * (max - min + 1 )) + min;
            },
            concactArrayParam: function (name, params) {
                var tempUrls = "?";
                angular.forEach(params, function (data, index, array) {
                    tempUrls = tempUrls + name + "=" + data + "&";
                });
                var url = tempUrls.substring(0, tempUrls.length - 1);
                //console.log("url is " + url);
                return url;
            },
            //不用这个判断，改用拦截器
            // showErrMsg: function (res) {
            //     if (res.data.code == -2) {
            //      //清除个人信息
            // managerService.clearSelfDetail();
            //         $rootScope.$broadcast("changeUserDate", "MainCtrl");
            //         $state.go("skill.login", {login: 0}, {reload: true});
            //     } else {
            //     }
            // },


            //判断链接是否有效
            verifyUrl: function (url, successFn, errorFn) {

                // 通过ajax请求状态码判断链接是否有效
                $.ajax({
                    url: "/checkurl/urlcheck?url=" + url,
                    method: "get",
                    success: function (res) {
                        if (res.code == 0) {
                            typeof successFn == 'function' && successFn();
                        } else {
                            typeof errorFn == 'function' && errorFn();
                        }
                    }
                });
                // $.ajax({
                //     type: 'get',
                //     url: url,
                //     cache: false,
                //     dataType: "jsonp", //跨域采用jsonp方式
                //     processData: false,
                //     timeout: 5000, //超时时间，毫秒
                //     complete: function (data) {
                //         // if (data.status == 200) {
                //         //githup验证有问题，所以先取消验证，强制执行successFn
                //         if (true) {
                //             typeof successFn == 'function' && successFn();
                //         } else {
                //             typeof errorFn == 'function' && errorFn();
                //         }
                //     }
                // });
                // }
            },

            //计算年龄
            personAge: function (year, month, day) {

                var time = new Date();
                var nowYear = time.getFullYear();
                var nowDay = time.getFullYear();
                var nowMonth = time.getFullYear();
                var age;

                //计算年龄
                if (nowYear == year) {
                    age = 0;//同年 则为0岁
                }
                else {
                    var ageDiff = nowYear - year; //年之差
                    if (ageDiff > 0) {
                        if (nowMonth == month) {
                            var dayDiff = nowDay - day;//日之差
                            if (dayDiff < 0) {
                                age = ageDiff - 1;
                            }
                            else {
                                age = ageDiff;
                            }
                        }
                        else {
                            var monthDiff = nowMonth - month;//月之差
                            if (monthDiff < 0) {
                                age = ageDiff - 1;
                            }
                            else {
                                age = ageDiff;
                            }
                        }
                    }
                    else {
                        age = -1;//返回-1 表示出生日期输入错误 晚于今天
                    }
                }

                age = nowYear - year;
                return age;
            },
            ////筛选出省份，城市
            //personAddress:function(addressList,addressId){
            //
            //    for(var i=0;i<addressList.length;i++){
            //        if(addressList. == addressId){
            //            vm.province = vm.provinceList[i].ProName;
            //            break;
            //        }
            //    }
            //},
            showReturnMsg: function (res, path) {

                switch (res.data.code) {
                    case 0:
                        $rootScope.alert(res.data.message, function () {
                            console.log(res.data.code + " get error  message is " + res.data.message);
                            if (path == undefined) {

                            } else {
                                $state.go(path, {}, {reload: true});
                            }
                        });
                        break;
                    case -5020:
                        $rootScope.alert(res.data.message, function () {
                            console.log(res.data.code + " get error  message is " + res.data.message);
                            $state.go("login", {}, {reload: true});
                        });
                        break;
                    default :
                        $rootScope.alert(res.data.message, function () {
                            console.log(res.data.code + " get error  message is " + res.data.message);
                        });

                }


            },
            isUpdate: function (id) {
                if (id == undefined) {
                    return false;
                } else {
                    return true;
                }
            },

            // 处理模块列表数据，将map添加进list结果
            buildTree: function (modules) {
                var tree = [];
                return this.buildTreeNode(0, null, tree, modules);
            },
            buildTreeNode: function (pid, node, tree, modules) {
                var now = this;
                angular.forEach(modules, function (data, index, array) {
                    var module = data;
                    if (module.parentID == pid) {
                        tree = now.buildTreeNode(module.id, module, tree, modules);
                        if (pid == 0) {
                            tree.push(module);
                        } else {
                            if (node.nodes == undefined) {
                                node.nodes = [];
                            }
                            node.nodes.push(module);
                        }
                    }
                });
                return tree;
            },
            arrayContains: function (array, obj) {
                for (var i = 0; i < array.length; i++) {
                    if (array[i] === obj) {
                        return true;
                    }
                }
                return false;
            },

            map2list: function (map) {

                var list = [];
                for (var p in map) {

                    list.push(map[p]);

                }
                // 最后显示所有的属性

                console.log(JSON.stringify(map) + " convert " + JSON.stringify(list));
                return list;
            },

            skillToJson: function (arr, template, theme) {
                var json = {
                    "root": {},
                    "template": template || "default",
                    "theme": theme || "fresh-blue"
                };
                var color = {
                    1: '#a6a6a6',
                    2: '#ffffff',
                    3: '#9bbb59',
                    4: '#4bacc6',
                    5: '#8064a2',
                    6: '#f79646'
                };
                var rootItem = arr.filter(function (item) {
                    return item.parent_id == '';
                })[0];

                json.root = {
                    data: {id: rootItem.id, text: rootItem.name, note: rootItem.content},
                    children: []
                };
                mapJson(json.root);

                function mapJson(json) {
                    var parent_id = '';

                    if (json.data) {
                        parent_id = json.data.id;
                    }

                    angular.forEach(arr, function (item) {
                        if (item.parent_id == parent_id) {
                            json.children.push({
                                data: {
                                    id: item.id,
                                    text: item.name,
                                    note: item.content,
                                    background: color[item.priority],
                                    sort: item.sort,
                                }, children: []
                            });
                        }
                    });
                    json.children = json.children.sort(function (a, b) {
                        return a.data.sort - b.data.sort;
                    });

                    if (json.children && json.children.length > 0) {
                        angular.forEach(json.children, function (item) {
                            mapJson(item);
                        })
                    }
                }

                return json;
            },

            //判断obj是否为空
            checkObjIsEmpty: function (obj) {
                var hasProp = false;
                for (var prop in obj) {
                    hasProp = true;
                    break;
                }
                if (!hasProp) {
                    return true;
                }
                else {
                    return false;
                }
            },
            //时间戳处理
            querySearchParams: function (params) {
                for (var k in params) {
                    if (params[k] instanceof Date) {
                        params[k] = new Date(params[k]).getTime();
                    }
                    // 处理 结束时间 那天末尾
                    if (k.toLowerCase().indexOf('end') != -1 && params[k]) {
                        var timeString = String(params[k]);
                        var str = timeString.substring(timeString.length - 1, timeString.length);
                        if (str != '9') {
                            params[k] = params[k] + 86400000 - 1;
                        }
                    }
                    if (k === 'page') {
                        params[k] = 1;
                    }
                }
                return params;
            },
            //判断用户类型，显示不同的名称
            getUserName: function (li) {
                //学员类型(user-type)：none：无名弟子未报班、  online：散修线上班 、 outline：外门线上班、 offline：内门线下班    默认none
                //学员身份(user-status)：10、无名弟子 20、散修弟子 30、外门弟子 40、内门弟子  50、首席弟子    60、真传弟子  70、修真长老  默认10
                var userName;
                //线下班级，显示[分院|身份]职业—昵称
                if (li.user.type == 'offline') {
                    userName = '[' + $filter('userTypeBranchCityFilter')(li.user.branch) + '|' + $filter('identityFilter')(li.user.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(li.user.oid)) + '-' + li.user.nick;
                    //无班级，显示[身份]昵称
                } else if (li.user.type == 'none') {
                    userName = '[' + $filter('identityFilter')(li.user.identity) + ']' + li.user.nick;
                    //非线下和无班级，显示[身份]职业—学号
                } else if (li.user.type != 'offline' && li.user.type != 'none') {
                    if (li.user.identity == 70) { //修真长老显示昵称
                        userName = '[' + $filter('identityFilter')(li.user.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(li.user.oid)) + '-' + li.user.nick;
                    } else {
                        userName = '[' + $filter('identityFilter')(li.user.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(li.user.oid)) + '-' + li.user.studyNumber;
                    }
                }
                return userName;
            }
        }
    })
    .factory('uploadService', function (path) {
        return {
            uploadFile: function (FileUploader) {
                return new FileUploader({
                    url: path.upload_url
                });
            }
        }
    });



