angular.module('skillApp')
    .directive('taskTab', function ($state, $location, taskService, $rootScope) {
        return {
            restrict: 'AE',
            scope: true,
            templateUrl: 'scripts/directives/taskTab/taskTab.html',
            link: function (scope) {
                scope.oid = $state.params.oid;
                scope.tid = $state.params.tid;

                taskService.getTaskList(scope.oid, "", 1, 30).then(function (res) {
                    if (res.data.code == 0) {
                        scope.tasks = res.data.data;
                    } else {
                        $rootScope.alert(res.data.message);
                    }
                });

                scope.changeType = function (tid) {
                    scope.tid = tid;
                    //$state.go('.', {oid: scope.oid, tid: tid, '#':$location.hash(),page: null});
                    $state.go('.', {oid: scope.oid, tid:  scope.tid, page: null});
                };

                //线上辅导
                scope.onlineGuide = function () {
                    window.open('daily/13278')

                }
            }
        }
    });