angular.module('skillApp')
    .directive('occupationTab', function($state,$location, positionService) {
        return {
            restrict: 'AE',
            scope: true,
            templateUrl: 'scripts/directives/occupationTab/occupationTab.html',
            link: function(scope) {
                scope.oid = $state.params.oid;
                positionService.positionList().then(function(res) {
                    if (res.data.code == 0) {
                        scope.occupations = res.data.data.occupations;
                    }
                });
                scope.changeType = function(oid) {
                    scope.oid = oid;
                    $state.go('.', {oid: oid, page: null});
                };
                //获取分院详情
                // scope.
            }
        }
    });