angular.module('skillApp')
    .directive('skillLegend', function () {
        return {
            restrict: 'E',
            scope: false,
            templateUrl: 'scripts/directives/skillLegend/skillLegend.html',
            link: function (scope) {
            }
        }
    });
