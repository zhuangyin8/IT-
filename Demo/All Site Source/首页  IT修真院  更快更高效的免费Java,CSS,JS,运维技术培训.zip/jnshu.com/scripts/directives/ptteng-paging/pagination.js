/**
 * Created by likui on 2016/6/26.
 */

angular.module('skillApp')
    .directive('pagination', function ($state) {
        return {
            restrict: 'EA',
            templateUrl: 'scripts/directives/ptteng-paging/pagination.html',
            replace: true,
            scope: {
                total: '@',
                size: '@',
                pageName: '@'
            },
            link: function (scope, element, attrs) {
                //当前页
                var activePage;
                if (scope.pageName == "dpage") { //技能文档
                    activePage = parseInt($state.params.dpage);
                } else if (scope.pageName == "vpage") { //技能视频
                    activePage = parseInt($state.params.vpage);
                } else {  //其他
                    activePage = parseInt($state.params.page);
                }

                if (isNaN(activePage) == true) {
                    activePage = 1;
                } else {
                    activePage = parseInt(activePage);
                }

                //page
                scope.pageName = scope.pageName || "page";
                //size
                scope.size = scope.size || $state.params.size ? scope.size || parseInt($state.params.size) : 10;


                //总页数
                var totalPage = Math.ceil(parseInt(scope.total) / scope.size);
                scope.activePage = activePage;
                scope.totalPage = totalPage;
                scope.isHaveNextPage = isHaveNextPage;
                scope.isHavePrePage = isHavePrePage;
                scope.pageList = getPageList();
                scope.isDisabled = isDisabled;
                scope.isActive = isActive;
                //是否有下一页
                function isHaveNextPage() {
                    if (activePage === totalPage) {
                        return false;
                    }
                    return true;
                }

                //是否有上一页
                function isHavePrePage() {
                    if (activePage !== 1) {
                        return true;
                    }
                    return false;
                }

                //获得pageList
                function getPageList() {
                    var pageList = [];
                    var notNum=false;

                    //...在两边
                    if (isHavePreDot() && isHaveNextDot()) {
                        for (var i = 0; i < 5; i++) {
                            pageList.push(activePage + i);
                        }
                        pageList.unshift("...");
                        pageList.push("...");
                    }

                    //...在前面
                    if (isHavePreDot() && !isHaveNextDot()) {
                        for (var i = totalPage - 4; i <= totalPage; i++) {
                            pageList.push(i);
                        }
                        pageList.unshift("...");
                        notNum = true;
                    }
                    //...在后面
                    if (!isHavePreDot() && isHaveNextDot()) {

                        if (totalPage > 5) {
                            for (var i = 0; i < 5; i++) {
                                pageList.push(activePage + i);
                            }
                        } else {
                            for (var i = 1; i < totalPage; i++) {
                                pageList.push(i);
                            }
                        }
                        pageList.push("...");
                    }
                    //没有...
                    if (!isHavePreDot() && !isHaveNextDot()) {

                        for (var i = 1; i <= totalPage; i++) {
                            pageList.push(i);
                        }
                    }
                    return pageList;
                }

                //是否有前面的 ...
                function isHavePreDot() {
                    if (activePage - 1 > 4) {
                        return true;
                    }
                    return false;
                }

                //是否有后面的 ...
                function isHaveNextDot() {
                    if (activePage < totalPage - 4) {
                        return true;
                    }
                    return false;
                }
                // Number(page) === activePage ||
                function isDisabled(page) {
                    if ( page === '...' || Number(page) > totalPage) {
                        return true;
                    }
                    return false;
                }

                function isActive(page) {
                    if (page === activePage) {
                        return true;
                    }
                    return false;
                }


                scope.changeInput = function () {
                    scope.jumpPage = scope.jumpPage.replace(/[^0-9]/g, '');
                    if (scope.jumpPage > totalPage) {
                        scope.jumpPage = totalPage;
                    }
                };

                scope.changeSize = function () {
                    scope.size = scope.size.replace(/[^0-9]/g, '');
                    if (parseInt(scope.size) === 0) {
                        scope.size = 10;
                    }
                };
                // 回车跳转页面
                scope.enterGoPage =function (e) {
                    var keycode = window.event?e.keyCode:e.which;
                  if(keycode==13){
                      scope.goPage(scope.jumpPage);
                  }
                };
                //跳页
                scope.goPage = function (page) {
                    if (isDisabled(page)) return;
                    if (scope.pageName == "dpage") { //技能文档
                        $state.go($state.current, {dpage: page || 1, size: scope.size}, {reload: true});
                    } else if (scope.pageName == "vpage") { //技能视频
                        $state.go($state.current, {vpage: page || 1, size: scope.size}, {reload: true});
                    } else {  //其他
                        $state.go($state.current, {page: page || 1, size: scope.size}, {reload: true});
                    }
                    // $state.go($state.current, {page: page || 1, size: scope.size}, {reload: true});
                };
            }
        }


    });