// angular.module('skillApp')
//     .directive('daily', function () {
//         return {
//             templateUrl: 'scripts/directives/selectTask/selectTask.html',
//             restrict: 'E',
//             replace: true,
//             scope: {
//                 cid: "@",
//                 name: "@"
//             },
//             controller: function ($timeout, $rootScope, $scope, $element, $document, $modal, classService, managerService, commonUtil, $state, constantService, imgService, dailyService, positionService) {
//                 var vm = $scope.vm = {};
//                 vm.cid = $state.params.cid;
//                 vm.positionName = $state.params.name;
//                 //vm.oid = constantService.positionName( vm.positionName).id;
//                 vm.oid = $state.params.oid;
//                 vm.task = '';
//                 vm.resultsUrl = '';
//                 vm.codeUrl = '';
//
//                 vm.userData = $rootScope.userData;
//                 positionService.getPositionDate(vm.oid).then(function (res) {
//                     if (res.data.code == 0) {
//                         vm.positionDate = res.data;
//
//                         //任务信息
//                         for (var b = 0; b < vm.positionDate.task.length; b++) {
//                             vm.positionDate.task[b].showTaskStep = 0;
//                         }
//                     }else {
//                         $rootScope.alert(res.data.message);
//                     }
//                 });
//
//                 /*$document.click=function(){
//                  $scope.$apply(function(){
//                  vm.selectTaskShow=0;
//                  });
//
//                  };
//                  $scope.stop=function(){
//                  return false;
//                  };*/
//                 function getClassDetail() {
//                     classService.getClassInfo([vm.cid]).then(function (res) {
//                         if (res.data.code == 0) {
//                             vm.data = res.data.data[0];
//                             angular.forEach(res.data.data[0].users, function (data) {
//                                 if (data.id == vm.userData.id) {
//                                     if (data.num < 10) {
//                                         data.num = "0" + data.num;
//                                     }
//                                     return vm.num = data.num;
//                                 }
//                             })
//                         }
//                         // else {
//                         //     commonUtil.showErrMsg(res);
//                         // }
//                         else {
//                             $rootScope.alert(res.data.message);
//                         }
//                     })
//                 }
//
//                 getClassDetail();
//
//
//                 vm.myDate = new Date().getTime();
//
//
//                 vm.taskMsg = [];
//                 $scope.selectTask = function (taskId, mineTaskNum) {
//                     if (vm.taskMsg.length == 0) {
//                         $('#taskCheck' + taskId).toggle();
//                         angular.forEach(vm.positionDate.task, function (data) {
//                             if (data.taskId == taskId) {
//                                 vm.taskMsg.push({"id": taskId, "msg": data.taskTitle, "mineTaskNum": mineTaskNum});
//                                 vm.taskId = taskId;
//                                 vm.mineTaskNum = mineTaskNum;
//                             }
//                         });
//                     }
//                     else if (vm.taskMsg.length > 0 && vm.taskMsg.length < 3) {
//                         $('#taskCheck' + taskId).toggle();
//                         var taskIsTrue = false;
//                         angular.forEach(vm.taskMsg, function (data) {
//                             if (data.id == taskId) {
//                                 return taskIsTrue = true;
//
//                             }
//                         });
//                         if (taskIsTrue) {
//                             var taskIndex;
//                             angular.forEach(vm.taskMsg, function (data, index) {
//                                 if (data.id == taskId) {
//                                     taskIndex = index;
//                                 }
//                             });
//                             vm.taskMsg.splice(taskIndex, 1);
//                         }
//                         else {
//                             angular.forEach(vm.positionDate.task, function (data) {
//                                 if (data.taskId == taskId) {
//                                     vm.taskMsg.push({"id": taskId, "msg": data.taskTitle, "mineTaskNum": mineTaskNum});
//                                     vm.taskId = taskId;
//                                     vm.mineTaskNum = mineTaskNum;
//                                 }
//                             });
//                         }
//                     }
//                     else {
//
//                         var taskIsTrue = false;
//                         angular.forEach(vm.taskMsg, function (data) {
//                             if (data.id == taskId) {
//                                 $('#taskCheck' + taskId).toggle();
//                                 return taskIsTrue = true;
//                             }
//                         });
//                         if (taskIsTrue) {
//                             var taskIndex;
//                             angular.forEach(vm.taskMsg, function (data, index) {
//                                 if (data.id == taskId) {
//                                     taskIndex = index;
//                                 }
//                             });
//                             vm.taskMsg.splice(taskIndex, 1);
//                         }
//                         else {
//                             vm.taskMsg = vm.taskMsg;
//                         }
//                     }
//
//
//                     vm.task = '';
//                     angular.forEach(vm.taskMsg, function (data) {
//                         vm.task = vm.task + "任务" + data.mineTaskNum + "——" + data.msg + "；";
//                     });
//
//
//                 };
//
//
//                 // 富文本编辑器实例化
//                 // 手动destory一遍，否则通过路由二次进入时会看不到编辑器
//                 $scope.$on('$destroy', function () {
//                     instance.destroy();
//                 });
//                 var instance = UM.getEditor('myEditor');
//
//
//                 vm.disableSubmit = false;
//                 //新建日报
//                 $scope.saveDaily = function () {
//                     vm.dailyContent = instance.getContent();
//                     vm.changeTask = [];
//                     angular.forEach(vm.taskMsg, function (data) {
//                         vm.changeTask.push(data.id);
//                     });
//                     if (vm.dailyTime == undefined) {
//                         vm.errorTip = "请选择日报时间";
//                         $timeout(function () {
//                             vm.errorTip = "";
//                         }, 3000);
//                     }
//                     else if (vm.dailyContent == '') {
//                         vm.errorTip = "请填写日报内容";
//                         $timeout(function () {
//                             vm.errorTip = "";
//                         }, 3000);
//                     }
//                     else if (vm.changeTask.length == 0) {
//                         vm.errorTip = "请选择日报任务";
//                         $timeout(function () {
//                             vm.errorTip = "";
//                         }, 3000);
//                     }
//                     else {
//                         vm.disableSubmit = true;
//                         var correctResultsUrl = vm.resultsUrl;
//                         var correctCodeUrl = vm.codeUrl;
//
//                         dailyService.newDaily(vm.cid, vm.changeTask, {
//                             dailyTime: vm.dailyTime,
//                             resultsUrl: correctResultsUrl,
//                             codeUrl: correctCodeUrl,
//                             content: vm.dailyContent
//                         }).then(function (res) {
//                             if (res.data.code == 0) {
//                                 //console.log(vm.dailyContent);
//                                 //$alert({title: '日报提交成功', content: '', placement: 'top', type: 'info', show: true, duration: 3});
//                                 //vm.disableSubmit = false;
//                                 vm.writeSuccess = 1;
//                                 if (vm.writeSuccess == 1) {
//                                     $timeout(function () {
//                                         if (res.data.code == 0) {
//                                             vm.writeSuccess = '';
//                                             managerService.clearDaily();//清掉草稿
//                                             $state.go('skill.positionDetail.dailyOccupation', {
//                                                 uid: vm.userData.id,
//                                                 cid: vm.cid,
//                                                 oid: vm.oid,
//                                                 name: vm.positionName,
//                                                 num: vm.num,
//                                                 page: 1
//                                             })
//                                         } else {
//                                             vm.disableSubmit = false;
//                                             $modal({title: '错误', content: res.data.message, show: true});
//                                             //commonUtil.showErrMsg(res);
//                                         }
//                                     }, 1000);
//                                 }
//                             }else {
//                                 $rootScope.alert(res.data.message);
//                             }
//                         });
//                     }
//
//                 };
//
//                 var onDocumentClick = function (e) {
//                     var isContained = $.contains($element[0], e.target) || $element[0] == e.target;
//
//                     if (vm.selectTaskShow == 1 && !isContained || vm.selectTaskShow == 1 && isContained && e.target.id != 'task') {
//                         $scope.$apply(function () {
//                             vm.selectTaskShow = 0;
//                         });
//                     }
//                 };
//                 $document.on('click.taskpicker', onDocumentClick);
//
//                 $scope.$on('$destroy', function () {
//                     $document.off('click.taskpicker');
//                 });
//
//
//                 //保存草稿
//                 vm.tip = "";
//                 function saveDraft() {
//                     managerService.saveDaily(instance.getContent());
//                     $scope.$apply(function () {
//                         vm.tip = "日报已成功保存为草稿";
//                     });
//                     $timeout(function () {
//                         vm.tip = "";
//                     }, 3000);
//                 }
//
//                 setInterval(function () {
//                     saveDraft();
//                 }, 30000);
//
//                 //取出草稿
//                 if (managerService.getDaily() != null) {
//                     instance.setContent(managerService.getDaily());
//
//                 }
//
//                 //火狐事件机制
//                 document.onkeydown = function (e) {
//
//                     e = e ? e : window.event;
//                 };
//                 document.onpaste = function (e) {
//
//                     e = e ? e : window.event;
//                 }
//             }
//         }
//     });
//
//
