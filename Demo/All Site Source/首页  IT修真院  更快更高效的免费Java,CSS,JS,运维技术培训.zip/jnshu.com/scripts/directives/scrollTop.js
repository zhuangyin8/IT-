angular.module('skillApp').directive('scrollOnClick', function() {
    return {
        restrict: 'A',
        link: function(scope, $elm) {
            $elm.on('click', function() {
                if(document.body.scrollTop)
                {
                    document.body.scrollTop = 0;
                }
                if(document.documentElement.scrollTop)
                {
                    document.documentElement.scrollTop = 0;
                }

            });
        }
    }
});