angular.module('skillApp').directive('loading', function () {
    return {
        templateUrl: 'scripts/directives/loading/loading.html',
        // template: '<div class="list-replace" ng-if="!getData"><div class="loader">loading...</div></div></div>',
        restrict: 'E',
        replace: true,
        scope: {
            info: "="
        },
        link: function (scope, ele, attrs) {
            scope.getData = false;
            scope.info.then(function (res) {
                if (res.data.code === 0) {
                    scope.getData = true;
                } else if (res.data.code == -15003) {
                    scope.getData = true;  //师弟日报接口-无师弟
                } else {

                }
            });

        },

        controller: function ($scope, $state) {
        }
    }
});


