/**
 * Created by Administrator on 2015/10/26.
 */
angular.module('skillApp')
    .factory('path', ['commonUtil', function (commonUtil) {

        return {
            //一、登录注册模块接口

            //测试用户名
            mobile: function (mobile) {
                return "/a/mobile?mobile=" + mobile;
            },
            //注册
            register: "/a/user",
            //登录
            login: "/a/login",
            //获取图形验证码
            getGenerate: "/a/captcha/generate",
            //图形验证码
            verifyCaptcha: function (Captcha) {
                return "/a/captcha/verify?inputValue=" + Captcha;
            },
            //verifyCaptcha: "/a/captcha/verify",
            //验证码发送
            postCode: "/a/code/send",
            //语音验证码发送
            postVoiceCode: "/a/code/voice",
            //忘记密码
            forgetPwd: "/a/password/forget",
            //注销
            logout: "/a/u/logout",

            //二、用户相关模块接口
            // 本人信息读取
            selfInfo: function () {
                return "/a/u/user/self?now=" + new Date().getTime(); // prevent disk cache;
            },
            // //用户信息读取
            // getUserInfo: function(uid){
            //     return "/a/user?uid="+uid;
            // },
            //批量获取用户信息读取改版，与cid统一，预备放弃上面那条getUserInfo
            getUserDetail: function (type, ids) {
                return "/a/user/detail/" + type + commonUtil.concactArrayParam("uids", ids);
            },
            //整体信息读取
            getAllInfo: function () {
                return "/a/info"
            },
            //修改密码
            changePwd: "/a/u/password",
            //修改个人信息
            changeUserInfo: "/a/u/user",
            //我的师弟
            getStudentInfo: function (uid, type, page, size) {
                return "/a/user/" + uid + "/student" + "?type=" + type + "&page=" + page + "&size=" + size;
            },
            //我的师兄
            getTeacherInfo: function (uid) {
                return "/a/user/" + uid + "/teacher"
            },
            //分配师兄
            allocateTeacher: function () {
                return "/a/u/teacher"
            },
            //用户任务进度
            userProgress: function () {
                return "/a/u/task/progress"
            },
            //用户技能
            userSkill: function () {
                return "/a/u/user/skill/detail"
            },

            //三、班级相关接口
            //职业相关
            //职业列表
            positionList: function () {
                return "/a/occupation/list";
            },
            //获取职业详情
            getPositionDate: function (oid) {
                return "/a/occupation/" + oid
            },
            positionName: function (oid) {
                return "/a/occupation/detail?oid=" + oid;
            },
            //用户班级列表
            userClassList: function (uid, page, size) {
                return "/a/user/class/list/" + uid + "?page=" + page + "&size=" + size;
            },
            //获取班级详情
            getClassInfo: function (params) {
                return "/a/classes/detail" + commonUtil.concactArrayParam("cid", params);
            },
            //获取至我的班级图标
            getMyClassInfo: function () {
                return "/a/u/user/self";
            },

            //获取班级列表
            getClassList: function () {
                return "/a/classes/search/query";
            },
            //获取职业信息列表
            getPositionCount: function () {
                return "/a/list/occupation/";
            },
            //获取职业人数情况
            getTheCount: function () {
                return "/a/count/occupation/";
            },

            //加入班级
            joinClass: function (cid) {
                return "/a/u/classmate/" + cid;
            },
            //退出班级
            quitClass: function () {
                return "/a/u/classes";
            },

            //任务相关
            //获取任务详情
            getTaskDetail: function (id) {
                return "/a/task/" + id;
            },
            //获取任务列表
            getTaskList: function (oid, id, page, size) {
                return "/a/task/search/query" + "?oid=" + oid + "&id=" + id + "&page=" + page + "&size=" + size;
            },
            // //领取任务
            // claimTask: function (tid) {
            //     return "/a/u/task/judgement/" + tid;
            // },
            // //任务提审
            // applyTask: function (tid) {
            //     return "/a/u/task/judgement/" + tid;
            // },
            // //任务审核
            // judgeTask: function (userTaskRelationId) {
            //     return "/a/u/task/judgement/teacher/" + userTaskRelationId;
            // },
            //任务接受、提交、审核
            taskReceiveAndSubmitAndReview: function (tid, type) {
                return "/a/u/task/" + tid + "/" + type;
            },
            //任务审核列表
            getjudgeListInfo: function (type, page, size) {
                return "/a/u/task/review/list" + "?type=" + type + "&page=" + page + "&size=" + size
            },
            //任务审核详情
            judgeDetail: function (userTaskRelationId) {
                return "/a/task/review/" + userTaskRelationId + "/detail";
            },

            //审核失败原因
            failReason: function (tid) {
                return "/a/u/task/judge/fail/" + tid;
            },
            //用户任务进度
            taskProgress: function (uid) {
                return "/a/task/progress/" + uid;
            },

            //四、日报相关接口
            //获取个人日报
            getClassmateDaily: function (uid, cid, page, size) {
                //如果有cid，则获取当前班级日报,若无则获取个人所有日报
                return "/a/user/daily/" + uid + "?cid=" + cid + "&page=" + page + "&size=" + size;
            },
            //获取日报列表
            getDailyList: function () {
                return "/a/daily/search/query"
            },
            //获取用户点赞/收藏 日报
            userDaily: function (type) {
                return "/a/u/daily/" + type + "/sort/list"
            },

            // 获取日报
            getDaily: function (did) {
                return "/a/daily/" + did;
            },
            // 审核日报
            judgeDaily: function (did, grateNum) {
                return "/a/u/daily/evalution/" + did + '?result=' + grateNum;
            },
            // 获取日报评论
            getDailyComment: function (did, uid, page, size, startAt, endAt) {
                return "/a/comment/search/query" + "?did=" + did + "&uid=" + uid + "&page=" + page + "&size=" + size + "&startAt=" + startAt + "&endAt=" + endAt;
            },
            // 获取上一篇/下一篇日报
            getOtherDaily: function (did, direction) {
                return "/a/daily/" + did + "/" + direction + "/detail"
            },

            //班级日报列表  这里有问题
            getClassesDailyLists: function (cid, page, size) {
                return "/a/class/daily/" + cid + "?page=" + page + "&size=" + size;
            },
            //删除日报
            delDaily: function (did) {
                return "/a/u/daily/" + did;
            },
            //新建日报
            newDaily: function (cid, task) {
                return "/a/u/daily/" + cid + commonUtil.concactArrayParam("task", task);
            },
            //修改日报
            changeDaily: function (did, task) {
                return "/a/u/daily/" + did + commonUtil.concactArrayParam("task", task);
            },
            //评论日报
            reviewDaily: function (did) {
                return "/a/u/comment/" + did;
            },


            //修改或删除评论
            updateOrDeleteDaily: function (commentId, params) {
                return "/a/u/comment/" + commentId;
            },

            //五、图片接口

            //上传图片接口
            uploadImg: function (module) {
                return "/a/u/img/" + module;
            },


            //七、用户收藏
            //获取用户收藏/推荐
            getUserDocument: function () {
                return "/a/u/my/document/search";
            },
            //删除用户收藏
            deleteUserDocument: function (documentId) {
                return "/a/u/document/collection/" + documentId
            },
            //新增文档
            addUserDocument: function () {
                return "/a/u/document";
            },
            //修改文档
            changeUserDocument: function (documentId) {
                return "a/u/document/" + documentId;
            },
            //文档点赞(点赞，取消赞在一起)
            likeDocument: function (documentId) {
                return "/a/u/document/like/" + documentId
            },
            //收藏文档(收藏，取消收藏在一起)
            collectionDocument: function (documentId) {
                return " /a/u/document/collection/" + documentId;
            },
            //点赞(目前仅用于日报)
            love: function (type, id, action) {
                return " /a/u/love/" + type + '/' + id + '/' + action;
            },
            //收藏(目前仅用于日报)
            collection: function (type, id, action) {
                return " /a/u/collection/" + type + '/' + id + '/' + action;
            },
            //获取技能文档(不必登录)
            getSkillDocument: function (sid) {
                return "/a/skill/document/" + sid;
            },
            //获取技能视频（不必登录）
            getSkillVideo: function (sid) {
                return "/a/skill/video/" + sid;
            },
            //获取技能文档(必须登录)
            uGetSkillDocument: function (sid, page, size) {
                return "/a/u/skill/document/" + sid + "?page=" + page + "&size=" + size;
            },
            //获取技能视频(必须登录)
            uGetSkillVideo: function (sid, page, size) {
                return "/a/u/skill/video/" + sid + "?page=" + page + "&size=" + size;
            },
            //获取书籍详情(未登录)
            nologinGetBookDetails: function (bid) {
                return "/a/book/document/" + bid;
            },
            //获取书籍详情（登录）
            loginGetBookDetails: function (bid) {
                return "/a/u/book/document/" + bid;
            },
            //四期新增
            //获取所有文档(必须登录)
            loginGetAllDocument: function () {
                return "/a/u/all/document";
            },
            //获取所有文档(不必登录)
            noLoginGetAllDocument: function () {
                return "/a/all/document";
            },
            //搜索资料
            informationSearch: function (sids) {
                return "/a/document/search" + commonUtil.concactArrayParam("sids", sids);
            },


            //八、技能接口
            //获得某个任务所用技能
            getTaskSkill: function (taskId) {
                return "/a/task/skill/list/" + taskId;
            },
            // 技能列表
            getSkillList: function (oid) {
                return "/a/skill/list/" + oid;
            },
            //获取技能详情
            getSkillDetail: function (sid) {
                return "/a/skill/detail/" + sid;
            },
            //获取完成技能的用户列表
            getSkillUser: function (sid, page, size) {
                return "/a/skill/" + sid + "/user/list" + "?page=" + page + "&size=" + size;
            },
            //获得职业任务所有技能列表
            getOccupationSkillList: function (oid) {
                return "/a/occupation/task/skill/" + oid
            },


            //职业日报列表
            getOccupationDailyLists: function (oid, page, size) {
                return "a/occupation/daily/" + oid + "?page=" + page + "&size=" + size;
            },

            //九  推荐视频、文档部分

            //技能文档数视频数
            getDocumentVideoNum: function (sid) {
                return "/a/document/count/" + sid;
            },
            //登录获取职业文档
            loginGetDocument: function (oid) {
                return "/a/u/occupation/document/" + oid;
            },
            //不登录获取职业文档
            noLoginGetDocument: function (oid) {
                return "/a/occupation/document/" + oid;
            },

            //十  日报读取状态
            sendDailyReadState: function (uid, did) {
                return "/diaryreadset" + "?uid=" + uid + "&did=" + did;
            },
            getDailyReadState: function (uid, dids) {
                return "/diaryread" + "?uid=" + uid + "&dids=" + dids;
            },

            //十一  任务详情内的接口
            getTaskDaily: function (tid, page, size) {
                return "/a/task/daily/" + tid + "?page=" + page + "&size=" + size;
            },

            //十二  获取所有日报
            getAllDaily: function (page, size) {
                if (!page) {
                    page = 1
                }
                if (!size) {
                    size = 10
                }
                return "/a/all/daily" + "?page=" + page + "&size=" + size;
            },
            //十三 寻找师兄
            getTeacher: function (params) {
                return '/a/user/list' + commonUtil.concactArrayParam("tid", params);
            },
            //获取视频列表
            videoList: function () {
                return '/a/user/video/list';
            },


            //十二   系统消息
            //获取系统消息列表
            getAlertList: function (type) {
                return "/a/u/receive/message/" + type + "/search" + "?now=" + new Date().getTime(); // prevent disk cache
            },
            //将用户收到的信息转送至服务器
            sendUserMsg: function (mobile, content) {
                return "/a/u/message/" + mobile + "?content=" + content;
            },
            //删除消息
            deleteUserMsg: function (mid) {
                return "/a/u/message/" + mid;
            },
            //消息已读
            sendAlertMsg: function (mid) {
                return "/a/u/read/message/" + mid
            },
            //群设置已读
            sendAllReady: function () {
                return "/a/u/read/message/all/"
            },
            //消息列表查看
            checkUserMsg: function () {
                return "/a/u/user/look"
            },
            //十三，云服务器发放
            //获取我的账号
            getAccount: function () {
                return " /a/u/account"
            },
            //账号详情
            accountDetails: function (id) {
                return "/a/u/account/" + id
            },
            //我的订单
            myOrder: function (page, size) {
                return "/a/u/order?" + "page=" + page + "&size=" + size
            },
            //我的订单
            orderDetails: function (id) {
                return "/a/u/order/" + id
            },
            //提交订单
            addOrder: function () {
                return "/a/u/order"
            },
            //删除订单
            delOrder: function (kid) {
                return "/a/u/order/" + kid
            },
            //确认收获
            confirm: function (id) {
                return " /a/u/order/confirm/" + id
            },
            //获取订单详情
            orderGoods: function (oid) {
                return "/a/u/goods/order/" + oid
            },
            //购物车列表
            getList: function (page, size) {
                return "/a/u/goods?" + "page=" + page + "&size=" + size
            },
            //加入购物车
            addList: function () {
                return "/a/u/goods"
            },
            //获取几个商品
            getListDetails: function (params) {
                return "/a/multi/goods" + commonUtil.concactArrayParam("ids", params)
            },
            //删除购物车
            delList: function (params) {
                return "/a/u/goods" + commonUtil.concactArrayParam("ids", params)
            },
            //支付
            submit: function (indentCode) {
                return " /pay/aliPay" + "?indentCode=" + indentCode
            }

        }

    }]);
