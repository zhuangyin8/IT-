angular.module('skillApp').controller('BannerCtrl', ['$state', '$rootScope', 'managerService', 'userService', '$filter', BannerCtrl]);
function BannerCtrl($state, $rootScope, managerService, userService, $filter) {
    var vm = this;

    if ($rootScope.userData && $rootScope.userData.id == $state.params.uid) { // 我的学院
        vm.uid = $rootScope.userData.id;

    } else { // TA的学院
        vm.uid = $state.params.uid;
    }

    userService.getUserDetail("full", [vm.uid]).then(function (res) {
        if (res.data.code == 0) {
            vm.userData = managerService.combineSelfDetail(res);
            // vm.userData.userName = commonUtil.getUserName(res.data.data);

            if (vm.userData.type == 'offline') {
                vm.userData.userName = '[' + $filter('userTypeBranchCityFilter')(vm.userData.branch) + '|' + $filter('identityFilter')(vm.userData.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(vm.userData.oid)) + '-' + vm.userData.nick;
                //无班级，显示[身份]昵称
            } else if (vm.userData.type == 'none') {
                vm.userData.userName = '[' + $filter('identityFilter')(vm.userData.identity) + ']' + vm.userData.nick;
                //非线下和无班级，显示[身份]职业—学号
            } else if (vm.userData.type != 'offline' && vm.userData.type != 'none') {
                if (vm.userData.identity == 70) { //修真长老显示昵称
                    vm.userData.userName = '[' + $filter('identityFilter')(vm.userData.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(vm.userData.oid)) + '-' + vm.userData.nick;
                } else {
                    vm.userData.userName = '[' + $filter('identityFilter')(vm.userData.identity) + ']' + $filter('uppercase')($filter('ProfessionalFilter')(vm.userData.oid)) + '-' + vm.userData.studyNumber;
                }
            }

        } else {
            $rootScope.alert(res.data.message);
        }
    });


    $rootScope.$on('userInfoChange', function () {
        vm.userData = $rootScope.userData;
    })

}