angular.module('skillApp')
    .controller('HomeCtrl', function ($scope, $location, commonUtil, positionService, userService, classService, $rootScope, $state, $timeout, $interval) {
        var vm = this;
        vm.goodStudentId = [6249, 7001, 6859, 4362];
        vm.goodTeacherId = [249, 1883, 1453, 1730];
        console.log("%c 修真院欢迎您", "color:red;font-size:30px");

        //获取班级和学员总数
        userService.getAllInfo().then(function (res) {
            if (res.data.code == 0) {
                vm.classCount = res.data.classCount;
                vm.classNum = res.data.classCount;
                vm.userCount = res.data.userCount;
                vm.userNum = res.data.userCount;
                vm.switch = 0;
                //滚动获取数量
                window.onscroll = function () {
                    vm.yTop = pageYOffset;
                    if (vm.switch == 0 && vm.yTop > 100 && vm.yTop < 500) {
                        getNum();
                    }
                }
            } else {
                $rootScope.alert(res.data.message);
            }
        });

        //循环
        function loopNum(num1, num2, num, fn) {
            if (num1 + num < num2) {
                num1 = num1 + num;
            } else {
                num1 = num2;
                if (typeof fn == "function") {
                    $interval.cancel(fn)
                }
            }
            return num1
        }

        //获取数量
        function getNum() {
            vm.switch = 1;
            vm.classNum = 0;
            vm.userNum = 0;
            var getClassNum = $interval(function () {
                vm.classNum = loopNum(vm.classNum, vm.classCount, 1, getClassNum)
            }, 1);
            var getUserNum = $interval(function () {
                vm.userNum = loopNum(vm.userNum, vm.userCount, 30, getUserNum)
            }, 1);
        }


        // 职业列表
        vm.background = ['bg-purple', 'bg-green', 'bg-skyblue', 'bg-red', 'bg-navyblue', 'bg-orange', 'bg-blue', 'bg-lightblue', 'bg-red', 'bg-navyblue'];
        positionService.positionList().then(function (res) {
            if (res.data.code == 0) {
                vm.occupations = [];
                angular.forEach(res.data.data.occupations, function (it) {

                    var position;
                    if (it.name == 'css' || it.name == 'js' || it.name == 'ios' || it.name == 'android') {
                        position = '前端工程师';
                    } else if (it.name == 'qa') {
                        position = '测试工程师';
                    }
                    else if (it.name == 'java') {
                        position = '后端工程师';
                    } else if (it.name == 'op') {
                        position = '运维工程师';
                    } else if (it.name == 'pm') {
                        position = '产品经理';
                    } else if (it.name == 'ui') {
                        position = '交互设计师';
                    } else {
                        position="";
                    }
                    var params = {
                        num: it.offlineUserCount + it.onlineUserCount,
                        id: it.id,
                        name: it.name.toUpperCase() + position
                    };

                    vm.occupations.push(params);

                });

                console.log(vm.occupations)


            }
            else {
                $rootScope.alert(res.data.message);
            }
        });


        //获取优秀师兄
        userService.getUserDetail("full", vm.goodTeacherId).then(function (res) {
            if (res.data.code == 0) {
                vm.goodTea = res.data.data.users;
                angular.forEach(vm.goodTea, function (item) {
                    if (item.oid != -1) {
                        item.occupation = res.data.data.occupations[item.oid].name
                    } else {
                        item.occupation = "暂无职业"
                    }

                })
            }
            else {
                $rootScope.alert(res.data.message);
            }
        });


        //报名学习
        $scope.signUpJudge = function () {
            if ($rootScope.userData) {
                window.open("hall/recommend");
            } else {
                $state.go('skill.login', {login: 0}, {reload: true});
            }
        };

        //接受任务
        $scope.acceptTaskJudge = function () {
            if ($rootScope.userData) {
                if ($rootScope.userData.cid != -1) {
                    vm.oid = $rootScope.userData.oid;
                    window.open("occupation/" + vm.oid + "/task");
                } else {
                    window.open("hall/recommend");
                }
            } else {
                $state.go('skill.login', {login: 0}, {reload: true});
            }
        };
        //写日报
        $scope.dailyJudge = function () {
            if ($rootScope.userData) {
                if ($rootScope.userData.cid != -1) {
                    //$state.go('skill.dailyCreate');
                    window.open("dailyCreate//");
                } else {
                    $rootScope.alert("加入班级才能写日报哦~", function () {
                        $timeout(function () {
                            window.open("hall/recommend");
                        }, 50)
                    });
                }
            } else {
                $state.go('skill.login', {login: 0}, {reload: true});
            }
        };

    });