angular.module('skillApp')
    .controller('ContentCtrl', ['$scope', '$state', '$rootScope', 'constantService', 'positionService', ContentCtrl]);
function ContentCtrl($scope, $state, $rootScope, constantService, positionService) {
    var vm = this;
}

