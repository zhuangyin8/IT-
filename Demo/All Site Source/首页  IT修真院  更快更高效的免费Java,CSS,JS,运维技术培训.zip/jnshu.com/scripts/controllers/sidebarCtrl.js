angular.module('skillApp')
    .controller('SidebarCtrl', ['$scope', '$state', '$rootScope', 'constantService', SidebarCtrl]);
function SidebarCtrl($scope, $state, $rootScope, constantService) {
    var vm = this;

    //获取侧边栏日报id
    vm.applyDaily = constantService.applyDaily;

    var sideConstant = {
        'hall': {
            title: false,
            level: 1,
            list: [
                {name: '职业推荐', 'url': 'skill.hall.recommend', icon: ''},
                {name: '职业列表', 'url': 'skill.hall.list', icon: ''},
                {name: '职业介绍', 'url': 'skill.hall.detail', params: '({oid: 1})', icon: ''}

            ]
        },
        'occupation': {
            title: false,
            level: 2,
            list: [
                {
                    type: '职业',
                    icon: 'fa fa-newspaper-o',
                    list: [
                        {name: '任务', 'url': 'skill.occupation.task'},
                        {name: '日报', 'url': 'skill.occupation.daily'}
                    ]

                },
                {
                    type: '技能',
                    icon: 'fa fa-trophy',
                    list: [
                        {name: '图图', 'url': 'skill.occupation.skillMinder'},
                        {name: '列表', 'url': 'skill.occupation.skillList'}
                    ]

                },
                {
                    type: '班级',
                    icon: 'fa fa-users',
                    list: [
                        {name: '内门', 'url': 'skill.occupation.classOffline'},
                        {name: '外门', 'url': 'skill.occupation.classOutline'},
                        {name: '散修', 'url': 'skill.occupation.classOnline'}
                    ]

                }
            ]
        },
        'my': {
            title: false,
            level: 2,
            list: [
                {
                    type: '我的学院',
                    icon: 'fa fa-institution',
                    list: [
                        {name: '我的班级', 'url': 'skill.school.class'},
                        {name: '我的日报', 'url': 'skill.school.daily'},
                        {name: '我的任务', 'url': 'skill.school.task'}
                    ]

                },
                {
                    type: '我的师兄',
                    icon: 'fa  fa-user',
                    list: [
                        {name: '我的师兄', 'url': 'skill.school.teacher'}
                    ]

                },
                {
                    type: '我的师弟',
                    icon: 'fa  fa-user',
                    list: [
                        {name: '我的师弟', 'url': 'skill.school.student'},
                        {name: '任务审核', 'url': 'skill.school.judgeList'},
                        {name: '师弟日报', 'url': 'skill.school.studentDaily'}
                    ]

                },
                {
                    type: '我的技能',
                    icon: 'fa fa-graduation-cap',
                    list: [
                        {name: '我的技能', 'url': 'skill.school.skill'}
                    ]

                },
                {
                    type: '我的推荐',
                    icon: 'fa fa-thumbs-up',
                    list: [
                        {name: '文档', 'url': 'skill.school.recommend', params: '({type: 1})'},
                        {name: '视频', 'url': 'skill.school.recommend', params: '({type: 2})'},
                        {name: '书籍', 'url': 'skill.school.recommend', params: '({type: 3})'},
                        {name: '日报', 'url': 'skill.school.recommendDaily', params: ''}
                    ]

                },
                {
                    type: '我的收藏',
                    icon: 'fa fa-star',
                    list: [
                        {name: '文档', 'url': 'skill.school.favourite', params: '({type: 1})'},
                        {name: '视频', 'url': 'skill.school.favourite', params: '({type: 2})'},
                        {name: '书籍', 'url': 'skill.school.favourite', params: '({type: 3})'},
                        {name: '日报', 'url': 'skill.school.favouriteDaily', params: ''}
                    ]

                },

                {
                    type: '我的通知',
                    icon: 'fa fa-envelope',
                    list: [
                        {name: '评论回复', 'url': 'skill.school.message', params: '({type:"daily",page:1})'},
                        {name: '班级变更', 'url': 'skill.school.message', params: '({type:"classes",page:1})'},
                        {name: '任务审核', 'url': 'skill.school.message', params: '({type:"task",page:1})'}
                    ]

                },
                {
                    type: '个人信息',
                    icon: 'fa fa-user',
                    list: [
                        {name: '个人资料', 'url': 'skill.school.data'},
                        {name: '修改密码', 'url': 'skill.school.password'}
                    ]

                },
                {
                    type: '我的云机',
                    icon: 'fa fa-cloud',
                    list: [
                        {name: '我的帐号', 'url': 'skill.school.account'}
                    ]

                },
                {
                    type: '我的订单',
                    icon: 'glyphicon glyphicon-inbox',
                    list: [
                        {name: '购物小车', 'url': 'skill.school.car'},
                        {name: '我的订单', 'url': 'skill.school.order'}
                    ]

                }
            ]
        },
        'other': {
            title: false,
            level: 2,
            list: [
                {
                    type: 'TA的学院',
                    icon: 'user-icon-1',
                    list: [
                        {name: 'TA的班级', 'url': 'skill.school.class'},
                        {name: 'TA的日报', 'url': 'skill.school.daily'}
                    ]

                },
                {
                    type: 'TA的师兄',
                    icon: 'user-icon-1',
                    list: [
                        {name: 'TA的师兄', 'url': 'skill.school.teacher'}
                    ]

                },
                {
                    type: 'TA的师弟',
                    icon: 'user-icon-1',
                    list: [
                        {name: 'TA的师弟', 'url': 'skill.school.student'}
                    ]

                },
                {
                    type: 'TA的推荐',
                    icon: 'user-icon-2',
                    list: [
                        {name: '文档', 'url': 'skill.school.recommend', params: '({type: 1})'},
                        {name: '视频', 'url': 'skill.school.recommend', params: '({type: 2})'},
                        {name: '书籍', 'url': 'skill.school.recommend', params: '({type: 3})'},
                        {name: '日报', 'url': 'skill.school.recommendDaily', params: ''}
                    ]

                },
                {
                    type: 'TA的收藏',
                    icon: 'user-icon-3',
                    list: [
                        {name: '文档', 'url': 'skill.school.favourite', params: '({type: 1})'},
                        {name: '视频', 'url': 'skill.school.favourite', params: '({type: 2})'},
                        {name: '书籍', 'url': 'skill.school.favourite', params: '({type: 3})'},
                        {name: '日报', 'url': 'skill.school.favouriteDaily', params: ''}
                    ]

                },
                {
                    type: 'TA的信息',
                    icon: 'user-icon-4',
                    list: [
                        {name: 'TA的资料', 'url': 'skill.school.data'}
                    ]

                }
            ]
        },
        'material': {
            title: false,
            level: 2,
            list: [
                {
                    type: '学习资料',
                    icon: 'fa fa-book',
                    list: [
                        {name: '文档', 'url': 'skill.material.document', icon: 'recommend-icon-doc recommend-icon'},
                        {name: '视频', 'url': 'skill.material.video', icon: 'recommend-icon-video recommend-icon'},
                        {name: '书籍', 'url': 'skill.material.book', icon: 'recommend-icon-book recommend-icon'},
                        {name: '日报', 'url': 'skill.material.daily', icon: 'fa fa-file-text-o'},
                        {
                            name: '小课堂',
                            'url': 'skill.daily',
                            params: '({did:14175})',
                            icon: 'fa fa-file-text-o',
                            'target': '_blank'
                        }
                    ]

                }, {
                    type: '线下报名',
                    icon: 'fa fa-university',
                    list: [
                        {
                            name: '北京报名',
                            'url': 'skill.daily',
                            params: '({did:vm.applyDaily.beijing})',
                            'target': '_blank'
                        },
                        {name: '武汉报名', 'url': 'skill.daily', params: '({did:vm.applyDaily.wuhan})', 'target': '_blank'},
                        {
                            name: '郑州报名',
                            'url': 'skill.daily',
                            params: '({did:vm.applyDaily.zhengzhou})',
                            'target': '_blank'
                        },
                        {
                            name: '成都报名',
                            'url': 'skill.daily',
                            params: '({did:vm.applyDaily.chengdu})',
                            'target': '_blank'
                        },
                        {
                            name: '深圳报名',
                            'url': 'skill.daily',
                            params: '({did:vm.applyDaily.shenzhen})',
                            'target': '_blank'
                        }

                    ]

                },
                {
                    type: '线上报名',
                    icon: 'fa fa-university',
                    list: [
                        {name: '任务辅导', 'url': 'skill.daily', params: '({did:13278})', 'target': '_blank'},
                        {name: '外门弟子', 'url': 'skill.daily', params: '({did:13736})', 'target': '_blank'}

                    ]

                },
                {
                    type: '学院公告',
                    icon: 'fa fa-bullhorn',
                    list: [
                        {name: '推荐优惠', 'url': 'skill.daily', params: '({did:3533})', 'target': '_blank'},
                        {name: '集赞优惠', 'url': 'skill.daily', params: '({did:9147})', 'target': '_blank'},
                        {name: '推荐书单', 'url': 'skill.daily', params: '({did:4085})', 'target': '_blank'}
                    ]

                },
                {
                    type: '新人必读',
                    icon: 'fa fa-file-text',
                    list: [
                        {name: '平台模式', 'url': 'skill.material.model'},
                        {name: '常见问题', 'url': 'skill.material.question'},
                        {name: '学习贴士', 'url': 'skill.material.tip'},
                        {name: '等级介绍', 'url': 'skill.material.level'},
                        {name: '关于我们', 'url': 'skill.material.us'},
                        {name: '联系我们', 'url': 'skill.material.contact'}
                    ]

                },
                {
                    type: '修真师兄',
                    icon: 'fa fa-file-text',
                    list: [
                        {name: '结业师兄', 'url': 'skill.material.offlineVideo'},
                        {name: '查找师兄', 'url': 'skill.material.searchTeacher'}
                    ]

                }
            ]
        },
        'class': {
            title: false,
            level: 1,
            list: [
                {name: '班级简介', 'url': 'skill.class.intro', icon: ''},
                {name: '班级同门', 'url': 'skill.class.mate', icon: ''},
                {name: '班级日报', 'url': 'skill.class.daily', icon: ''}
            ]
        },
        'task': {
            title: false,
            level: 1,
            list: [
                {name: '任务详情', 'url': 'skill.task.detail', icon: ''},
                {name: '任务日报', 'url': 'skill.task.daily', icon: ''}
            ]
        },
        'novice': {
            title: false,
            level: 2,
            list: [
                {name: '平台模式', 'url': 'skill.novice.model', icon: ''},
                {name: '常见问题', 'url': 'skill.novice.question', icon: ''},
                {name: '学习贴士', 'url': 'skill.novice.tip', icon: ''},
                {name: '关于我们', 'url': 'skill.novice.us', icon: ''},
                {name: '联系我们', 'url': 'skill.novice.contact', icon: ''}
            ]
        }
    };

    vm.sideState = $state.current.parents;

    if (vm.sideState && vm.sideState == 'novice') {
        vm.sideMenu = sideConstant.material;
    } else if (vm.sideState && vm.sideState != 'school') {
        vm.sideMenu = sideConstant[vm.sideState];
    } else if (vm.sideState && vm.sideState == 'school') {
        if ($rootScope.userData && $rootScope.userData.id == $state.params.uid) {
            vm.sideMenu = sideConstant.my;
        } else {
            vm.sideMenu = sideConstant.other;
        }
    }

    vm.getUrl = function (li) {
        //如果参数为undefined置为空，不然下面拼字符串会出错
        if (li.params == undefined) {
            li.params = ""
        }
        //新打开窗口，侧边栏不高亮
        if (li.target == undefined) {
            vm.currentUrl = li.url + li.params;
        }


    };

    vm.activePanel = 0;
    angular.forEach(vm.sideMenu.list, function (items, index) {
        angular.forEach(items.list, function (item) {
            // 特殊已选子菜单,需要通过参数来进行对比判断
            if (item.params) {
                var itemParams = item.params.match(/\{[^\)]+\}/g);
                var itemParamString = itemParams[0].replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2": ');
                if ($state.current.name == 'skill.school.message') {
                    var itemParamJSON = JSON.parse(itemParamString);
                    if ($state.params.type == itemParamJSON.type) {
                        vm.activePanel = index;
                        item.selected = true;
                        return false;
                    } else {
                    }
                } else {
                }
                // 普通已选子菜单
            } else {
                if (item.url == $state.current.name) {
                    //url和state要保持一致才能用这种方法判断
                    vm.activePanel = index;
                    item.selected = true;
                    return false;
                }
            }

        })
    })

}
