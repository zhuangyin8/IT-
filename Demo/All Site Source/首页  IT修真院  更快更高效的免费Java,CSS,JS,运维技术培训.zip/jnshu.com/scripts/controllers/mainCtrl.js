angular.module('skillApp')
    .controller('MainCtrl', ['$rootScope', 'imService', '$scope',
        'managerService', 'loginService', '$state', 'userService', 'constantService', '$location', MainCtrl]);
function MainCtrl($rootScope, imService, $scope,
                  managerService, loginService, $state, userService, constantService, $location) {
    var vm = $scope.vm = {};

    $scope.$state = $state;

    //判断日报出处 日报详情页和日报列表页导航高亮
    vm.dailyUrl = $location.absUrl();
    if (vm.dailyUrl.indexOf('daily') >= 0) {
        var onlineParams = ["oid", "tid", "cid", "occupation", "task", "class"]; //线上学习：职业日报详情、任务日报详情、班级日报详情、职业日报列表、任务日报列表、班级日报列表
        var schoolParams = ["uid", "teacherUid", "message", "school"]; //我的学院：个人日报详情、师弟日报详情、消息评论回复、个人和师弟日报列表

        function indexOfItem(item) {
            return vm.dailyUrl.indexOf(item) >= 0;
        }

        if (onlineParams.some(indexOfItem)) {
            vm.onlineDaily = true;
        } else if (schoolParams.some(indexOfItem)) {
            vm.schoolDaily = true;
        } else {
            vm.materialDaily = true;  // 学习资料：所有日报无参数
        }
    }
    //点击导航赋值
    $scope.statusJudge = function () {
        vm.onlineDaily = false;
        vm.schoolDaily = false;
        vm.materialDaily = false;
    };
    //获取侧边栏日报id
    vm.applyDaily = constantService.applyDaily;

    //我的消息，需要刷新页面，所以写在js里面
    vm.message = function () {
        $state.go('skill.school.message', {uid: $rootScope.userData.id, type: "daily", page: 1}, {reload: true});
        //加uid是为了确认是个人页面还是TA人页面
    };

    // 检测版本更新
    if (48 > localStorage.ver) {
        //清除个人信息
        // managerService.clearSelfDetail();
        // $rootScope.alert("系统检测到版本更新，请重新登录", function () {
        //     //不能加reload:true 否则会进入死循环
        //     $state.go('skill.login', {login: 0});
        // })
        localStorage.ver = 48;
    }

    if ($rootScope.userData) {
        selfInfo($rootScope.userData.id);
        toIm();
    } else {
    }

    //获取本地用户信息
    function selfInfo(uid) {
        //后台手动将用户推出班级时，本地存储个人信息需更新，故需要重新向接口请求
        // userService.getUserDetail('full', [uid]).then(function (res) {
        userService.selfInfo().then(function (res) {
            if (res.data.code == 0) {
                //存储个人信息
                var userInfo = managerService.combineSelfDetail(res);
                managerService.saveSelfDetail(userInfo);
                $rootScope.userData = managerService.getSelfDetail();
                //右上角职业信息
                vm.positionDate = userInfo.occupation;
                //获取未读消息数量
                $rootScope.messagesNumber = res.data.data.users[0].isLook;
            }
            else {
                $rootScope.alert(result.data.message);
            }
        });
    }

    function toIm() {
        //调用环信方法
        imService.imFunction($rootScope.userData.mobile, $rootScope.userData.id, vm);
    }


    vm.showNav = function () {
        $('#navbar-collapse').collapse('hide')
    };


    var weixinBtn = document.getElementById('weixin-share-img');
    var weixin = document.getElementById('share-weixin');
    var ruxue = document.getElementById('ruxue');
    var title1 = document.getElementById("title1");

    $scope.title1 = function () {
        document.title = "首页 | IT修真院"
    };
    $scope.title2 = function () {
        document.title = "职业殿堂 | IT修真院"
    };
    $scope.title3 = function () {
        document.title = "我的学院 | IT修真院"
    };
    $scope.title4 = function () {
        document.title = "新人必读 | IT修真院"
    };
    $scope.title5 = function () {
        document.title = "关于我们 | IT修真院"
    };
    $scope.title6 = function () {
        document.title = "推荐资源 | IT修真院"
    };


    weixinBtn.onmousemove = function () {
        weixin.style.display = 'block';
    };
    weixinBtn.onmouseout = function () {
        weixin.style.display = 'none';
    };

    $scope.backTop = function () {
        window.scrollTo(0, 0);
    };
    $scope.backBottom = function () {
        window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
    };

    //滚动回顶部按钮
    $('#scrollTop').hide();


    $scope.scrollBtnState = function () {
        var scrollTopBtn = $('#scrollTop');
        var scrollBottomBtn = $('#scrollBottom');
        var position = document.body.scrollTop || document.documentElement.scrollTop;
        var height = document.body.scrollHeight || document.documentElement.scrollHeight;
        if (position > 10) {
            scrollTopBtn.show();
        } else {
            scrollTopBtn.hide();
        }
        if (position + document.documentElement.clientHeight + 10 > height) {
            scrollBottomBtn.hide();
        } else {
            scrollBottomBtn.show();
        }

    };

    $(window).scroll(function () {
        $scope.scrollBtnState();
    });

    // 数字转数组，便于根据数字进行repeat
    $scope.numArray = function (num) {
        return new Array(num);
    };

    // 判断是否是数组
    $scope.isArray = function (params) {
        return angular.isArray(params);
    };

    //退出登录
    $scope.UserLogout = function () {
        loginService.logout().then(function (res) {
            if (res.data.code == 0) {
                //清除个人信息
                managerService.clearSelfDetail();
                localStorage.login = 'false';
                $state.go('skill.home', {}, {reload: true});
            } else {
                $rootScope.alert(res.data.message);
            }

        })
    };

}






