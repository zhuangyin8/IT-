/**
 * Created by Administrator on 2015/11/10.
 */
'use strict';

angular.module('skillApp')
//昵称
    .filter('nickFilter', function (NICK) {
        return function (nick) {
            if (nick == '') {
                var random = Math.floor(Math.random() * 11);
                nick = "小" + NICK[random];
            }
            return nick;
        }
    })


    //默认头像
    .filter("defaultAvatar", function (constantService) {
        return function (thumb) {
            if (thumb == undefined || thumb == '') {
                return constantService.defaultThumb;
            } else {
                return thumb;
            }
        }

    })

    //用户类型-简写-过滤器
    .filter('userTypeSimpleFilter', function (userTypeSimple) {
        return function (type) {
            return userTypeSimple[type];
        }
    })
    //用户类型-全称-过滤器
    .filter('userTypeComplexFilter', function (userTypeComplex) {
        return function (type) {
            return userTypeComplex[type];
        }
    })

    //职业介绍成长周期输出数字
    .filter('num', function () {
        return function (cycle) {
            if (cycle) {
                return cycle.replace(/[\u4e00-\u9fa5]/gi, "");
            }
        }
    })
    //职业介绍成长周期输出单位
    .filter('unit', function () {
        return function (cycle) {
            if (cycle) {
                return cycle.replace(/[^\u4e00-\u9fa5]/gi, "");
            }
        }
    })

    //用户等级文字
    .filter('levelTextFilter', function (levelText) {
        return function (title) {
            if (title !== "" && title !== undefined) {
                return levelText[title]
            }

        }
    })
    //用户身份
    .filter('identityFilter', function (identity) {
        return function (title) {
            if (title !== "" && title !== undefined) {
                return identity[title]
            }

        }
    })
    //用户等级图标
    .filter('levelIconFilter', function (levelIcon) {
        return function (title) {
            if (title !== "" && title !== undefined) {
                return levelIcon[title]
            }
        }
    })
    //用户等级图片
    .filter('userTypePicFilter', function (userTypePic) {
        return function (type) {
            return userTypePic[type];

        }
    })

    //每天规划学时
    .filter('hourPerDayFilter', function (hourPerDay) {
        return function (key) {
            if (key !== "" && key !== undefined) {
                return hourPerDay[key]
            }
        }
    })
    //用户资质
    .filter('abilityFilter', function (ability) {
        return function (key) {
            if (key !== "" && key !== undefined) {
                return ability[key]
            }
        }
    })
    //薪资描述
    .filter('salaryDescriptionFilter', function (salary) {
        return function (salaryTag) {
            if (salaryTag !== "" && salaryTag !== undefined) {
                return salary[salaryTag - 1].description
            }else {
                return salary[0].description; //默认养活自己
            }
        }
    })
    //薪资范围
    .filter('salaryRangeFilter', function (salary) {
        return function (salaryTag) {
            if (salaryTag !== "" && salaryTag !== undefined) {
                return salary[salaryTag - 1].range;
            }else {
                return salary[0].range; //默认6K以下
            }
        }
    })
    //任务状态
    .filter('taskStatusFilter', function (taskStatus) {
        return function (status) {
            if (status !== "" && status !== undefined) {
                return taskStatus[status]
            }
        }
    })
    //任务动作
    .filter('taskActionFilter', function (taskAction) {
        return function (action) {
            if (action !== "" && action !== undefined) {
                return taskAction[action]
            }
        }
    })
    //消息类别
    .filter('messageTypeFilter', function (messageType) {
        return function (type) {
            if (type !== "" && type !== undefined) {
                return messageType[type]
            }
        }
    })
    //日报评级
    .filter('evaluationFilter', function (evaluation) {
        return function (type) {
            if (type !== "" && type !== undefined) {
                return evaluation[type].name
            }
        }
    })
    //数字转化成汉字
    .filter('numToTextFilter', function (numToText) {
        return function (num) {
            if (num !== "" && num !== undefined) {
                return numToText[num]
            }
        }
    })
    //职业
    .filter('ProfessionalFilter', function (profession) {
        return function (id) {
            return profession[id];

        }
    })


    //所在分院
    .filter('userTypeBranchCityFilter', function (userTypeBranchCity) {
        return function (type) {
            if (type !== "" && type !== undefined) {
                return userTypeBranchCity[type];
            } else {
                return userTypeBranchCity[10]; //接口有问题，先默认展示北京分院
            }
        }

    })

    //性别
    .filter('sexFilter', function (sex) {
        return function (type) {
            return sex[type];

        }
    })

    //订单类型
    .filter('indentStatusFilter', function (indentStatus) {
        return function (id) {
            if (id !== '' && id !== undefined) {
                return indentStatus[id - 1].name;
            }
        }
    })

    //服务器状态
    .filter('accountStatus', function (accountStatus) {
        return function (id) {
            if (id !== '' && id !== undefined) {
                return accountStatus[id - 1].name;
            }
        }
    })


    //服务器类别
    .filter('cloudTypeFilter', function (cloudType) {
        return function (type) {
            return cloudType.type[type]
        }
    })


;
