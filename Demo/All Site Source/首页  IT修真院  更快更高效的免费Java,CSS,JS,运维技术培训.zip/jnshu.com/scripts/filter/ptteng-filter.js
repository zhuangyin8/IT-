angular.module('skillApp')
//省
    .filter('provinceFilter', function (PROVINCE) {
        return function (id) {
            if (!id) {
                return "";
            }
            var result = PROVINCE.filter(function (item) {
                return item.ProID == id
            });
            return result[0].ProName ? result[0].ProName : "";
        }
    })
    //市
    .filter('cityFilter', function (CITY) {
        return function (id) {
            if (!id) {
                return "";
            }
            var result = CITY.filter(function (item) {
                return item.CityID == id
            });
            return result[0] ? result[0].CityName : "";
        }
    })

    //判空显示为0
    .filter('SentenceEmpty', function () {
        return function (id) {
            if (id == undefined || id == '') {
                return 0;
            } else {
                return id;
            }
        }

    })
    //没有参数的时候显示0
    .filter("return0", function () {
        return function (id) {
            if (id == undefined || id == '') {
                return 0;
            } else {
                return id;
            }
        }

    })
    //年龄
    .filter('ageFilter', function () {
        return function (birthday) {
            if (birthday) {
                return new Date().getFullYear() - new Date(birthday).getFullYear();
            } else {
                return '';
            }
        }
    })
    //富文本编辑器
    .filter('to_trusted', function ($sce) {
        return function (text) {
            return $sce.trustAsHtml(text);
        }
    })
    //手机号显示*
    .filter('phoneFilter', function () {
        return function (num) {
            return num.substring(0, 3) + "******" + num.substring(9, 11);
        }
    })
;
