'use strict';


function httpConfig($httpProvider) {
    // Use x-www-form-urlencoded Content-Type
    $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    $httpProvider.defaults.headers.patch['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
    $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';

    // set up global transformRequest function
    $httpProvider.defaults.transformRequest = function (data) {
        if (data === undefined) {
            return data;
        }
        return $.param(data);
    };
    //拦截器
    $httpProvider.interceptors.push(function ($rootScope, $q) {
        return {
            request: function (config) {
                return config;
            },
            responseError: function (rejection) {
                return $q.reject(rejection);
            },
            response: function (response) {
                //cookie失效
                if (response.data.code == -2) {
                    $rootScope.userData = undefined;
                    if (localStorage.login == 'true') {
                        localStorage.login = 'false';
                        $rootScope.alert("系统检测到您登录状态异常，请重新登录", function () {
                            //清除用户信息
                            localStorage.removeItem("self");
                            $rootScope.$state.go('skill.login', {login: 0});
                        });
                        return;
                    } else {
                        return
                    }
                } else {
                    return response;
                }


            }
        }
    });


}
function lazyLoadConfig($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({
        modules: [
            {
                name: 'ngStrapLightbox',
                files: [
                    '/bower_components/angular-translate/angular-translate.js?ver=48',
                    '/bower_components/angular-strap-lightbox/angular-strap-lightbox.js?ver=48',
                    '/bower_components/angular-strap-lightbox/angular-strap-lightbox.css?ver=48'
                ]
            },
            {
                name: 'bootstrapLightbox',
                files: [
                    '/bower_components/angular-bootstrap/ui-bootstrap.js?ver=48',
                    '/bower_components/angular-bootstrap-lightbox/angular-bootstrap-lightbox.css?ver=48'
                ]
            },
            {
                name: 'fancybox',
                files: [
                    '/bower_components/jquery/jquery.mousewheel.pack.js?ver=48',
                    '/bower_components/fancyBox/jquery.fancybox.css?ver=48',
                    '/bower_components/fancyBox/jquery.fancybox.js?ver=48'

                ]
            },
            {
                name: 'magnificPopup',
                files: [
                    'bower_components/magnific-popup/jquery.magnific-popup.min.js?ver=48',
                    'scripts/directives/angular-magnific-popup-directive.js?ver=48',
                    'bower_components/magnific-popup/magnific-popup.css?ver=48'
                ]
            },
            {
                name: 'magnific-popup',
                files: [
                    //'bower_components/magnific-popup/jquery.magnific-popup.min.js?ver=48',
                    //'/app/scripts/directives/angular-magnific-popup-directive.js?ver=48',
                    'bower_components/magnific-popup/magnific-popup.css?ver=48'
                ]
            },
            {
                name: 'summernote',
                files: [
                    '/styles/editor/summernote.css?ver=48',
                    '/scripts/editor/summernote.js?ver=48',
                    '/scripts/editor/summernote-zh-CN.js?ver=48',
                    '/bower_components/angular-summernote/angular-summernote.js?ver=48'

                ]
            },
            {
                name: 'onlyNum',
                files: [
                    'scripts/controllers/cloud/onlyNum.js?ver=48'
                ]
            },
            {
                name: 'umeditor',
                files: [
                    '/bower_components/umeditor/themes/default/css/umeditor.css?ver=48',
                    '/bower_components/umeditor/umeditor.config.js?ver=48',
                    '/bower_components/umeditor/umeditor.js?ver=48',
                    '/bower_components/umeditor/lang/zh-cn/zh-cn.js?ver=48'
                    //'/bower_components/umeditor/angular-ueditor.js?ver=48'

                ]
            },
            {
                name: 'metaUmeditor',
                files: [
                    '/bower_components/umeditor/themes/default/css/umeditor.css?ver=48',
                    '/bower_components/umeditor/umeditor.config.js?ver=48',
                    '/bower_components/umeditor/umeditor.js?ver=48',
                    '/bower_components/umeditor/lang/zh-cn/zh-cn.js?ver=48',
                    '/bower_components/umeditor/metaUmeditor.js?ver=48'

                ]
            },
            {
                name: 'kityminderCore',
                files: [
                    '/bower_components/kityminder-core/kity.min.js?ver=48',
                    '/bower_components/kityminder-core/kityminder.core.css?ver=48',
                    '/bower_components/kityminder-core/kityminder.core.min.js?ver=48',
                    '/scripts/directives/kityminder/kityminder.js?ver=48'
                ]
            },
            {
                name: 'kityminderEditor',
                files: [
                    '/bower_components/codemirror/lib/codemirror.css?ver=48',
                    '/bower_components/hotbox/hotbox.css?ver=48',
                    '/bower_components/color-picker/dist/color-picker.min.css?ver=48',
                    '/bower_components/codemirror/lib/codemirror.js?ver=48',
                    '/bower_components/codemirror/mode/xml/xml.js?ver=48',
                    '/bower_components/codemirror/mode/javascript/javascript.js?ver=48',
                    '/bower_components/codemirror/mode/css/css.js?ver=48',
                    '/bower_components/codemirror/mode/htmlmixed/htmlmixed.js?ver=48',
                    '/bower_components/codemirror/mode/markdown/markdown.js?ver=48',
                    '/bower_components/codemirror/addon/mode/overlay.js?ver=48',
                    '/bower_components/codemirror/mode/gfm/gfm.js?ver=48',
                    '/bower_components/angular-ui-codemirror/ui-codemirror.js?ver=48',
                    '/bower_components/marked/lib/marked.js?ver=48',
                    '/bower_components/hotbox/hotbox.js?ver=48',
                    '/bower_components/json-diff/json-diff.js?ver=48',
                    '/bower_components/color-picker/dist/color-picker.min.js?ver=48',
                    '/bower_components/kityminder-core/kity.min.js?ver=48',
                    '/bower_components/kityminder-core/kityminder.core.css?ver=48',
                    '/bower_components/kityminder-core/kityminder.core.min.js?ver=48',
                    '/bower_components/kityminder-editor/kityminder.editor.min.css?ver=48',
                    '/bower_components/kityminder-editor/kityminder.editor.min.js?ver=48'
                ]
            },
            {
                name: 'promiseBtn',
                files: [
                    'scripts/directives/promise-button/promise-button/directive.css?ver=48',
                    'scripts/directives/promise-button/promise-button/directive.js?ver=48']
            },
            {
                name: 'promiseBtn',
                files: [
                    'scripts/directives/promise-button/promise-button/directive.css?ver=48',
                    'scripts/directives/promise-button/promise-button/directive.js?ver=48']
            },
            {
                name: 'echarts',
                files: [
                    'bower_components/echarts/echarts.min.js?ver=48',
                    'scripts/directives/charts/charts.js?ver=48',
                    'scripts/directives/charts/charts.css?ver=48'
                ]
            }
        ]
    });
}

!(function () {
    angular.module('skillApp', ['oc.lazyLoad', 'ui.router', 'lazyload', 'ngCookies', 'mgcrea.ngStrap', 'ngMessages'])
        .config(httpConfig)
        .config(lazyLoadConfig)
        .config(function ($stateProvider, $urlRouterProvider, $ocLazyLoadProvider, $locationProvider) {
            var _lazyLoad = function (loaded) {
                return function ($ocLazyLoad) {
                    return $ocLazyLoad.load(loaded, {serie: true});
                }
            };

            $ocLazyLoadProvider.config({
                debug: false,
                events: true
            });


            $locationProvider.html5Mode(true);

            $urlRouterProvider.otherwise('/home');
            /*
             * 路由设置
             * */

            var version = "?ver=48";

            $stateProvider.state('skill', {
                // base
                url: '',
                templateUrl: 'views/main.html' + version,
                controller: 'MainCtrl',
                resolve: {
                    loadMyFile: _lazyLoad([
                        'scripts/controllers/mainCtrl.js' + version,
                        'scripts/controllers/sidebarCtrl.js' + version,
                        'scripts/controllers/contentCtrl.js' + version,
                        'scripts/controllers/my/bannerCtrl.js' + version,
                        'scripts/directives/ptteng-paging/pagination.css' + version,
                        'scripts/directives/ptteng-paging/pagination.js' + version,
                        'scripts/directives/loading/loading.js' + version,
                        'scripts/directives/loading/loading.css' + version,
                        'scripts/directives/scrollTop.js' + version,
                        'scripts/directives/occupationTab/occupationTab.js' + version,
                        'scripts/directives/taskTab/taskTab.js' + version,
                        'scripts/directives/skillLegend/skillLegend.js' + version,
                        'promiseBtn'
                    ])
                },
                redirectTo: 'skill.home'
            })
            // 首页
                .state('skill.home', {
                    url: '/home',
                    views: {
                        "": {
                            templateUrl: 'views/home.html' + version,
                            controller: 'HomeCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/homeCtrl.js' + version])
                    }
                })


                // 职业殿堂
                .state('skill.hall', {
                    url: '/hall',
                    views: {
                        "sidebar": {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        "content": {templateUrl: 'views/content.html' + version}
                    },
                    redirectTo: 'skill.hall.recommend'
                })
                // 职业殿堂-职业推荐
                .state('skill.hall.recommend', {
                    url: '/recommend',
                    parents: 'hall',
                    templateUrl: 'views/hall/occupationRecommend.html' + version,
                    controller: 'OccupationRecommendCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/OccupationRecommendCtrl.js' + version])
                    }
                })
                // 职业列表
                .state('skill.hall.list', {
                    url: '/list',
                    parents: 'hall',
                    templateUrl: 'views/hall/occupationList.html' + version,
                    controller: 'OccupationListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/OccupationListCtrl.js' + version])
                    }
                })
                // 职业详情
                .state('skill.hall.detail', {
                    url: '/detail/:oid',
                    parents: 'hall',
                    templateUrl: 'views/hall/occupationDetail.html' + version,
                    controller: 'OccupationDetailCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/hall/OccupationDetailCtrl.js' + version,
                            'echarts'
                        ])
                    }
                })


                // 单个职业介绍
                .state('skill.occupation', {
                    url: '/occupation/:oid',
                    views: {
                        'sidebar': {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        'content': {
                            templateUrl: 'views/content.html' + version,
                            controller: 'ContentCtrl as vm'
                        }
                    },
                    redirectTo: 'skill.occupation.task'
                })

                // -职业任务
                .state('skill.occupation.task', {
                    url: '/task',
                    parents: 'occupation',
                    templateUrl: 'views/task/taskList.html' + version,
                    controller: 'TaskListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/task/TaskListCtrl.js' + version

                        ])
                    }
                })
                // 职业日报
                .state('skill.occupation.daily', {
                    url: '/daily?page&orderBy&sort',
                    parents: 'occupation',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 职业技能脑图
                .state('skill.occupation.skillMinder', {
                    url: '/skillMinder',
                    parents: 'occupation',
                    templateUrl: 'views/hall/skillMinder.html' + version,
                    controller: 'SkillMinderCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/SkillMinderCtrl.js' + version,
                            'magnificPopup',
                            'kityminderCore'
                        ])
                    }
                })
                // 职业技能列表
                .state('skill.occupation.skillList', {
                    url: '/skillList',
                    parents: 'occupation',
                    templateUrl: 'views/hall/skillList.html' + version,
                    controller: 'SkillListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/SkillListCtrl.js' + version])
                    }
                })
                // 单个职业介绍-线上班级
                .state('skill.occupation.classOnline', {
                    url: '/classOnline?page',
                    parents: 'occupation',
                    templateUrl: 'views/hall/occupationClass.html' + version,
                    controller: 'OccupationClassCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/OccupationClassCtrl.js' + version])
                    }
                })
                // 单个职业介绍-线下班级
                .state('skill.occupation.classOffline', {
                    url: '/classOffline/:branch/?page',
                    parents: 'occupation',
                    templateUrl: 'views/hall/occupationClass.html' + version,
                    controller: 'OccupationClassCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/OccupationClassCtrl.js' + version])
                    }
                })
                // 单个职业介绍-外门班级
                .state('skill.occupation.classOutline', {
                    url: '/classOutline?page',
                    parents: 'occupation',
                    templateUrl: 'views/hall/occupationClass.html?ver=40',
                    controller: 'OccupationClassCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/hall/OccupationClassCtrl.js?ver=40'])
                    }
                })

                //职业任务
                .state('skill.task', {
                    url: '/task/:oid/:tid',
                    views: {
                        'sidebar': {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        'content': {templateUrl: 'views/content.html' + version},
                        'taskFooter': {
                            templateUrl: 'views/task/taskFooter.html' + version
                        }
                    },
                    redirectTo: 'skill.task.detail'
                })
                // 任务详情
                .state('skill.task.detail', {
                    url: '/detail',
                    parents: 'task',
                    templateUrl: 'views/task/taskDetail.html' + version,
                    controller: 'TaskDetailCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/task/TaskDetailCtrl.js' + version,
                            'magnificPopup'
                        ])
                    }
                })
                // 任务日报
                .state('skill.task.daily', {
                    url: '/daily?page&orderBy&sort',
                    parents: 'task',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 技能资料
                .state('skill.skillMaterial', {
                    url: '/skillMaterial/:sid/:type?dpage&vpage',
                    views: {
                        '': {
                            templateUrl: 'views/task/skillMaterial.html' + version,
                            controller: 'SkillMaterialCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/task/SkillMaterialCtrl.js' + version])
                    }
                })
                // 完成此技能用户详情列表
                .state('skill.skillUser', {
                    url: '/skillUser/:sid/:value?page',
                    views: {
                        '': {
                            templateUrl: 'views/task/skillUser.html' + version,
                            controller: 'skillUserCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/task/SkillUserCtrl.js' + version])
                    }
                })

                // 班级
                .state('skill.class', {
                    url: '/class/:cid/:breadcrumb',  //breadcrumb 为1表示从班级列表进去，需显示面包屑
                    views: {
                        'sidebar': {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        'content': {templateUrl: 'views/content.html' + version}
                    },
                    redirectTo: 'skill.class.intro'
                })
                // 班级-班级简介
                .state('skill.class.intro', {
                    url: '/intro',
                    parents: 'class',
                    templateUrl: 'views/class/intro.html' + version,
                    controller: 'IntroCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/class/introCtrl.js' + version])
                    }
                })
                // 班级-班级同门
                .state('skill.class.mate', {
                    url: '/mate',
                    parents: 'class',
                    templateUrl: 'views/class/mate.html' + version,
                    controller: 'IntroCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/class/introCtrl.js' + version])
                    }
                })
                // 班级日报
                .state('skill.class.daily', {
                    url: '/daily?page&orderBy&sort',
                    parents: 'class',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 线下报名
                .state('skill.offline', {
                    url: '/offline',
                    templateUrl: 'views/offline/offline.html' + version,
                    controller: 'offlineCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/offline/offlineCtrl.js' + version,
                            'styles/offline/offline.css' + version
                        ])
                    }

                })

                // 我的学院
                .state('skill.school', {
                    url: '/school/:uid',
                    views: {
                        "banner": {
                            templateUrl: 'views/my/banner.html' + version,
                            controller: 'BannerCtrl as vm'
                        },
                        "sidebar": {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        "content": {
                            templateUrl: 'views/content.html' + version,
                            controller: 'MyCtrl as vm'
                        },
                        "schoolFooter": {
                            templateUrl: 'views/my/schoolFooter.html' + version,
                            controller: 'MyCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/myCtrl.js' + version])
                    },
                    redirectTo: 'skill.school.class'
                })
                // 我的学院-班级
                .state('skill.school.class', {
                    url: '/class',
                    parents: 'school',
                    templateUrl: 'views/my/userClass.html' + version,
                    controller: 'UserClassCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/UserClassCtrl.js' + version])
                    }
                })
                // 个人日报
                .state('skill.school.daily', {
                    url: '/daily?page&orderBy&sort',
                    parents: 'school',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 我的学院-任务
                .state('skill.school.task', {
                    url: '/task',
                    parents: 'school',
                    templateUrl: 'views/task/taskList.html' + version,
                    controller: 'TaskListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/task/TaskListCtrl.js' + version])
                    }
                })
                // 我的师弟
                .state('skill.school.student', {
                    url: '/student/:type?page',
                    parents: 'school',
                    templateUrl: 'views/my/student.html' + version,
                    controller: 'studentCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/studentCtrl.js' + version
                        ])
                    }
                })
                // 日报审核列表
                .state('skill.school.judgeList', {
                    url: '/judgeList/:type?page&size',
                    parents: 'school',
                    templateUrl: 'views/my/judgeList.html' + version,
                    controller: 'judgeListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/judgeListCtrl.js' + version,
                            'styles/my/judgeList.css' + version
                        ])
                    }
                })
                // 日报审核详情
                .state('skill.school.judgeDetail', {
                    url: '/judgeDetail/:userTaskRelationId/:type',
                    parents: 'school',
                    templateUrl: 'views/my/judgeDetail.html' + version,
                    controller: 'judgeDetailCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/judgeDetailCtrl.js' + version,
                            'styles/my/judgeDetail.css' + version
                        ])
                    }
                })

                // 我的师兄
                .state('skill.school.teacher', {
                    url: '/teacher',
                    parents: 'school',
                    templateUrl: 'views/my/teacher.html' + version,
                    controller: 'teacherCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/teacherCtrl.js' + version
                        ])
                    }
                })
                // 师弟日报
                .state('skill.school.studentDaily', {
                    url: '/studentDaily?page&orderBy&sort',
                    parents: 'school',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })

                // 活动页面
                .state('activity', {
                    url: '/activity/:uid',
                    templateUrl: 'views/my/activity.html' + version,
                    controller: 'ActivityCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'styles/activity/activity.css' + version,
                            'scripts/controllers/my/activityCtrl.js' + version
                        ])
                    }
                })

                // 分享页面
                .state('share', {
                    url: '/share?uid',
                    templateUrl: 'views/my/share.html' + version,
                    controller: 'ShareCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'styles/activity/share.css' + version,
                            'scripts/controllers/my/shareCtrl.js' + version
                        ])
                    }
                })

                // 我的收藏（文档、视频、书籍）
                .state('skill.school.favourite', {
                    url: '/favourite/:type/:orderBy/:sort?page',
                    parents: 'school',
                    templateUrl: 'views/my/myFavoriteAndRecommend.html' + version,
                    controller: 'myFavoriteAndRecommendCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/myFavoriteAndRecommendCtrl.js' + version])
                    }
                })
                // 我的收藏（日报）
                .state('skill.school.favouriteDaily', {
                    url: '/favouriteDaily?page&orderBy&sort',
                    parents: 'school',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 我的推荐（文档、视频、书籍）
                .state('skill.school.recommend', {
                    url: '/recommend/:type/:orderBy/:sort?page',
                    parents: 'school',
                    templateUrl: 'views/my/myFavoriteAndRecommend.html' + version,
                    controller: 'myFavoriteAndRecommendCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/myFavoriteAndRecommendCtrl.js' + version])
                    }
                })
                // 我的推荐（日报）
                .state('skill.school.recommendDaily', {
                    url: '/recommendDaily?page&orderBy&sort',
                    parents: 'school',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })

                // 我的学院-消息
                .state('skill.school.message', {
                    url: '/message/:type?page',
                    parents: 'school',
                    templateUrl: 'views/my/message.html' + version,
                    controller: 'MessageCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/messageCtrl.js' + version,
                            'scripts/directives/compile-bind.js' + version
                        ])
                    }
                })
                // 我的学院-我的技能
                .state('skill.school.skill', {
                    url: '/skill',
                    parents: 'school',
                    templateUrl: 'views/my/mySkill.html' + version,
                    controller: 'mySkillCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/mySkillCtrl.js' + version,
                            'magnificPopup',
                            'kityminderCore'
                        ])
                    }
                })
                // 我的学院-个人资料
                .state('skill.school.data', {
                    url: '/data',
                    parents: 'school',
                    templateUrl: 'views/my/data.html' + version,
                    controller: 'DataCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/dataCtrl.js' + version,
                            'scripts/directives/dateDropdown.js' + version,
                            'scripts/directives/simpleUpload.js' + version
                        ])
                    }
                })
                // 我的学院-修改密码
                .state('skill.school.password', {
                    url: '/password',
                    parents: 'school',
                    templateUrl: 'views/my/password.html' + version,
                    controller: 'PasswordCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/passwordCtrl.js' + version,
                            'scripts/directives/pwCheck.js' + version
                        ])
                    }
                })
                // 我的学院-账户安全
                .state('skill.school.accountSafe', {
                    url: '/accountSafe',
                    parents: 'school',
                    templateUrl: 'views/my/accountSafe.html' + version,
                    controller: 'accountSafeCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/accountSafeCtrl.js' + version
                        ])
                    }
                })
                // 我的学院-帐号
                .state('skill.school.account', {
                    url: '/account',
                    parents: 'school',
                    templateUrl: 'views/my/account.html' + version,
                    controller: 'AccountCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/accountCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version
                        ])
                    }
                })
                // 我的学院-服务器套餐
                .state('skill.school.setMeal', {
                    url: '/setMeal/:id/:type/:accountId',
                    parents: 'school',
                    templateUrl: 'views/my/setMeal.html' + version,
                    controller: 'SetMealCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/setMealCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version,
                            'bower_components/angularjs-slider/rzslider.js' + version,
                            'bower_components/angularjs-slider/rzslider.css' + version,
                            'onlyNum'
                        ])
                    }
                })
                // 我的学院-服务器购买
                .state('skill.school.pay', {
                    url: '/pay/:id',
                    parents: 'school',
                    templateUrl: 'views/my/pay.html' + version,
                    controller: 'PayCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/payCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version])
                    }
                })
                // 我的学院-服务器购买须知
                .state('skill.school.notice', {
                    url: '/notice',
                    parents: 'school',
                    templateUrl: 'views/my/notice.html' + version,
                    controller: 'SetMealCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'styles/cloud/shoppingCar.css' + version
                        ])
                    }
                })
                // 我的学院-购物车
                .state('skill.school.car', {
                    url: '/car?page',
                    parents: 'school',
                    templateUrl: 'views/my/car.html' + version,
                    controller: 'CarCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/my/carCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version,
                            'onlyNum'
                        ])
                    }
                })
                // 我的学院-我的订单
                .state('skill.school.order', {
                    url: '/order?page',
                    parents: 'school',
                    templateUrl: 'views/my/order.html' + version,
                    controller: 'OrderCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/orderCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version
                        ])
                    }
                })
                // 我的学院-订单详情
                .state('skill.school.orderDetail', {
                    url: '/orderDetail/:id/:status',
                    parents: 'school',
                    templateUrl: 'views/my/orderDetail.html' + version,
                    controller: 'OrderDetailCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/my/orderDetailCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version])
                    }
                })
                //账号详情
                .state('skill.school.accountDetails', {
                    url: '/accountDetails/:id',
                    parents: 'school',
                    templateUrl: 'views/cloudServerAccount/accountDetails.html' + version,
                    controller: "accountDetailsCtrl",
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'styles/cloud/shoppingCar.css' + version,
                            'scripts/controllers/cloud/accountDetailsCtrl.js' + version
                        ])
                    }
                })
                //支付成功
                .state('skill.school.success', {
                    url: '/success/:id',
                    parents: 'school',
                    templateUrl: 'views/cloudServerAccount/success.html' + version,
                    controller: "successCtrl",
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/cloud/successCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version
                        ])
                    }
                })
                //结算
                .state('skill.school.submitOrder', {
                    url: '/submitOrder?params&id',
                    parents: 'school',
                    templateUrl: 'views/cloudServerAccount/submitOrder.html' + version,
                    controller: "submitOrderCtrl",
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/cloud/submitOrderCtrl.js' + version,
                            'styles/cloud/shoppingCar.css' + version
                        ])
                    }
                })

                // 兼容-系统消息-直接跳转到相应路由上
                .state('skill.compatibleOther', {
                    url: '/skill/class/detail//:cid/:type/:oid',
                    redirectTo: 'skill.class'
                })
                .state('skill.compatibleClass', {
                    url: '/skill/Information/:uid/UserClass/:id/:type',
                    redirectTo: 'skill.school'
                })
                .state('skill.compatibleDaily', {
                    url: '/skill/daily/detail///:oid/:uid/:xid/:did//:yid//:occ/look/',
                    redirectTo: 'skill.daily'
                })



                // 写日报
                .state('skill.dailyCreate', {
                    url: '/dailyCreate/:oid/:tid',
                    views: {
                        "": {
                            templateUrl: 'views/daily/dailyCreate.html' + version,
                            controller: 'DailyCreateCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/daily/DailyCreateCtrl.js' + version,
                            'metaUmeditor'
                        ])
                    }
                })

                // 日报详情
                .state('skill.daily', {
                    url: '/daily/:did?tid&cid&oid&teacherUid&uid&page',
                    views: {
                        "": {
                            templateUrl: 'views/daily/dailyDetail.html' + version,
                            controller: 'DailyDetailCtrl as vm'
                        }
                    },
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/daily/DailyDetailCtrl.js' + version,
                            'metaUmeditor',
                            'scripts/directives/delegate-click.js' + version
                        ])
                    }
                })

                // 学习资料
                .state('skill.material', {
                    url: '/material',
                    views: {
                        "sidebar": {
                            templateUrl: 'views/sidebar.html' + version,
                            controller: 'SidebarCtrl as vm'
                        },
                        "content": {
                            templateUrl: 'views/content.html' + version
                        }
                    },
                    redirectTo: 'skill.material.document'
                })
                //文档
                .state('skill.material.document', {
                    url: '/document/:type/:oid/:rating/:name/:userType/:studyNumber/:sort/:orderBy?page&size',
                    parents: 'material',
                    templateUrl: 'views/material/meterialList.html' + version,
                    controller: 'MeterialListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/material/meterialListCtrl.js' + version,
                            'kityminderCore'
                        ])
                    }
                })
                //视频
                .state('skill.material.video', {
                    url: '/video/:orderBy/:sort/:type/:rating/:oid/:userType/:studyNumber/:name?page&size',
                    parents: 'material',
                    templateUrl: 'views/material/meterialList.html' + version,
                    controller: 'MeterialListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/material/meterialListCtrl.js' + version,
                            'kityminderCore'
                        ])
                    }
                })
                //书籍
                .state('skill.material.book', {
                    url: '/book/:orderBy/:sort/:type/:rating/:oid/:userType/:studyNumber/:name?page&size',
                    parents: 'material',
                    templateUrl: 'views/material/meterialList.html' + version,
                    controller: 'MeterialListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/material/meterialListCtrl.js' + version,
                            'scripts/directives/simpleUpload.js' + version,
                            'kityminderCore'
                        ])
                    }
                })
                //资料日报
                .state('skill.material.daily', {
                    url: '/daily/:tid/:oid/:userType/:evaluation/:startAt/:endAt/:studyNumber/:sort/:orderBy?page',
                    parents: 'material',
                    templateUrl: 'views/daily/dailyList.html' + version,
                    controller: 'DailyListCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/daily/DailyListCtrl.js' + version])
                    }
                })
                // 新人必读
                //平台模式
                .state('skill.material.model', {
                    url: '/model',
                    parents: 'material',
                    templateUrl: 'views/novice/model.html' + version,
                    controller: 'ModelCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/noviceModeCtrl.js' + version,
                            'styles/terrace.css' + version
                        ])
                    }

                })
                //常见问题
                .state('skill.material.question', {
                    url: '/question',
                    parents: 'material',
                    templateUrl: 'views/novice/question.html' + version
                })
                //学习贴士
                .state('skill.material.tip', {
                    url: '/tip',
                    parents: 'material',
                    templateUrl: 'views/novice/tip.html' + version
                })
                //等级介绍
                .state('skill.material.level', {
                    url: '/level',
                    parents: 'material',
                    templateUrl: 'views/novice/level.html' + version
                })
                //关于我们
                .state('skill.material.us', {
                    url: '/us',
                    parents: 'material',
                    templateUrl: 'views/about/us.html' + version
                })
                //联系我们
                .state('skill.material.contact', {
                    url: '/contact',
                    parents: 'material',
                    templateUrl: 'views/about/contact.html' + version
                })

                //线下师兄（视频集）
                .state('skill.material.offlineVideo', {
                    url: '/offlineVideo/:page/:size',
                    parents: 'material',
                    templateUrl: 'views/offline/offlineVideo.html' + version,
                    controller: 'offlineVideoCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/offline/offlineVideoCtrl.js' + version,
                            'styles/offline/offlineVideo.css' + version,
                            'scripts/directives/embedSrc.js' + version
                        ])
                    }
                })
                //查找师兄
                .state('skill.material.searchTeacher', {
                    url: '/searchTeacher/:type/:oid/:tid/:branch/:identity/:level/:studyStartAt/:studyEndAt/:graduatedStartAt/:graduatedEndAt/:nick/:studyNumber/:page/:size/:close',
                    parents: 'material',
                    templateUrl: 'views/offline/searchTeacher.html',
                    controller: 'searchTeacherCtrl as vm',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/offline/searchTeacherCtrl.js?ver=40'
                        ])
                    }
                })
                // 视频
                // .state('skill.material.video', {
                //     url: '/video/:orderBy/:sort/:type/:rating/:oid/:userType/:studyNumber/:name?page&size',
                //     parents: 'material',
                //     templateUrl: 'views/material/meterialList.html'+version,
                //     controller: 'MeterialListCtrl as vm',
                //     resolve: {
                //         loadMyFile: _lazyLoad([
                //             'scripts/controllers/material/meterialListCtrl.js'+version,
                //             'kityminderCore'
                //         ])
                //     }
                // })
                //加入班级、
                .state('skill.join', {
                    url: '/join/:cid/:oid',
                    templateUrl: 'views/class/join.html' + version,
                    controller: 'joinCtrl',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/class/joinCtrl.js' + version
                        ])
                    }
                })
                //加入班级反馈
                .state('skill.feedback', {
                    url: '/feedback/:cid/:oid',
                    templateUrl: 'views/class/feedback.html' + version,
                    controller: 'feedbackCtrl',
                    resolve: {
                        loadMyFile: _lazyLoad([
                            'scripts/controllers/class/feedbackCtrl.js' + version
                        ])
                    }
                })

                //登录、注册、
                .state('skill.login', {
                    url: '/login/:login',
                    templateUrl: 'views/login/login.html' + version,
                    controller: "LoginCtrl",
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/login/LoginCtrl.js' + version,
                            'scripts/directives/numberic-input.js' + version,
                            'styles/login.css' + version

                        ])
                    }
                })
                //注册成功
                .state('skill.registerFeedback', {
                    url: '/registerFeedback',
                    templateUrl: 'views/login/registerFeedback.html' + version,
                    controller: "registerFeedback",
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/login/RegisterFeedback.js' + version

                        ])
                    }
                })
                //忘记密码
                .state('skill.forgetPassword', {
                    url: '/forgetPassword',
                    templateUrl: 'views/login/forgetPassword.html' + version,
                    controller: "ForgetPwdCtrl",
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/login/ForgetPwdCtrl.js' + version,
                            'scripts/directives/pwCheck.js' + version,
                            'styles/login.css' + version
                        ])
                    }
                })
                // 求职
                .state('skill.partner', {
                    url: '/partner',
                    templateUrl: 'views/partner/partner.html' + version
                })
                .state('skill.partner.eking', {
                    url: '/eking',
                    parents: 'partner',
                    templateUrl: 'views/partner/eking.html' + version
                })
                .state('skill.partner.weiying', {
                    url: '/weiying',
                    parents: 'partner',
                    templateUrl: 'views/partner/weiying.html' + version
                })
                .state('skill.partner.headhunting', {
                    url: '/headhunting',
                    parents: 'partner',
                    templateUrl: 'views/partner/headhunting.html' + version
                })
                .state('skill.partner.duomei', {
                    url: '/duomei',
                    parents: 'partner',
                    templateUrl: 'views/partner/duomei.html' + version
                })
                .state('skill.partner.t-think', {
                    url: '/t-think',
                    parents: 'partner',
                    templateUrl: 'views/partner/t-think.html' + version
                })
                //环信页面
                .state('skill.im', {
                    url: '/im/',
                    templateUrl: '../views/alert/im.html' + version,
                    controller: 'imCtrl',
                    resolve: {
                        loadMyFile: _lazyLoad(['scripts/controllers/imCtrl.js' + version
                        ])
                    }
                })

                //下载页
                .state('download', {
                    url: '/download',
                    templateUrl: '../views/download/download.html' + version
                });

            // // 图表页
            // .state('charts', {
            //     url: '/charts',
            //     templateUrl: 'scripts/directives/charts/charts.html?' + Date(),
            //     resolve: {
            //         loadMyFile: _lazyLoad([
            //             'scripts/directives/charts/charts.js',
            //             'scripts/directives/charts/charts.css'
            //         ])
            //     }
            //
            // });
        })
        .run(function ($rootScope, $templateCache, $cookies, $state, $location, $anchorScroll, $window, $modal, managerService) {

            $rootScope.$on('$stateChangeStart', function (evt, to, params) {
                if (to.redirectTo) {
                    evt.preventDefault();
                    $state.go(to.redirectTo, params, {location: 'replace'})
                }

            });

            // $anchorScroll.yOffset = 50;

            /*
             $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {});*/
            $rootScope.$on('$stateChangeSuccess', function () {
                $rootScope.userData = managerService.getSelfDetail();
                if ($rootScope.userData == undefined && $location.path().indexOf('/dailyCreate') != -1) {
                    $state.go("skill.login", {login: 0}, {reload: true});
                    return false;
                }
                window.scrollTo(0, 0);
            });
            $rootScope.alert = function (content, okFn) {
                var modal = $modal({
                    html: true,
                    show: false,
                    templateUrl: 'views/template/ptteng-alert-0.0.1.html?ver=48',
                    controller: function ($scope) {
                        $scope.content = content;
                        $scope.ok = function () {
                            typeof okFn == 'function' && okFn();
                            modal.$promise.then(modal.hide);
                        };
                        window.onpopstate = function () {
                            modal.$promise.then(modal.hide);
                        };
                    }
                });
                modal.$promise.then(modal.show);
            };
            $rootScope.confirm = function (content1, content2, okFn, cancelFn) {
                var modal = $modal({
                    html: true,
                    show: false,
                    templateUrl: 'views/template/ptteng-confirm-0.0.1.html?ver=48',
                    controller: function ($scope) {
                        $scope.content1 = content1;
                        $scope.content2 = content2;
                        $scope.ok = function () {
                            typeof okFn == 'function' && okFn();
                            modal.$promise.then(modal.hide);
                        };
                        $scope.cancel = function ($scope) {
                            typeof cancelFn == 'function' && cancelFn();
                            modal.$promise.then(modal.hide);
                        };
                        window.onpopstate = function () {
                            $scope.cancel();
                        };
                    }
                });
                modal.$promise.then(modal.show);
            };
            $rootScope.confirm1 = function (content1, content2, okFn, cancelFn) {
                var modal = $modal({
                    html: true,
                    show: false,
                    templateUrl: 'views/template/pay-confirm.html?ver=48',
                    controller: function ($scope) {
                        $scope.content1 = content1;
                        $scope.content2 = content2;
                        $scope.ok = function () {
                            typeof okFn == 'function' && okFn();
                            modal.$promise.then(modal.hide);
                        };
                        $scope.cancel = function ($scope) {
                            typeof cancelFn == 'function' && cancelFn();
                            modal.$promise.then(modal.hide);
                        };
                        window.onpopstate = function () {
                            $scope.cancel();
                        };
                    }
                });
                modal.$promise.then(modal.show);
            };
            //$rootScope.success = function (content) {
            //    var modal = $modal({
            //        html: true,
            //        show: false,
            //        templateUrl: 'views/template/ptteng-confirm-0.0.2.html?ver=48',
            //        controller: function ($scope) {
            //            $scope.content = content;
            //            var close = function () {
            //                modal.$promise.then(modal.hide);
            //            };
            //            setTimeout("close()",time)
            //
            //        }
            //    });
            //    modal.$promise.then(modal.show);
            //};

            $rootScope.goToUserSchool = function (uid) {
                window.open("school/" + uid + "/class")
            };

            // 全局配置
            $rootScope.$state = $state;
            $rootScope.isLogin = function () {
                var loginCookie = "admin.jnshu.com";
                return !!$cookies[loginCookie];
            };

        })

})();